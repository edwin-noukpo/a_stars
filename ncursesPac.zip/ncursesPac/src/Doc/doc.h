/// @mainpage Documentation Main Page
///
/// _Classic PACMAN game in terminal._ <br /><br />
///
/// Written in C++ using ncurses as a seminar project in PA2.
///
/// Jan Sokol 2015
