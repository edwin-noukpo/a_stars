/*
** EPITECH PROJECT, 2024
** MY_NAVY
** File description:
** Function to count number of word in a function
*/

#ifndef _Edwin_
    # define _Edwin_

#endif /* !Edwin */
