/*
** EPITECH PROJECT, 2024
** palindrome
** File description:
** palindrome
*/


#ifndef STRUCT_H_
    #define STRUCT_H_

typedef struct open_s {
    int g_cost;
    int h_cost;
    int f_cost;
    int x_pos;
    int y_pos;
    int x_prev;
    int y_prev;
    struct open_s *n;
} open_t;

typedef struct closed_s {
    int x_pos;
    int y_pos;
    struct closed_s *n;
} closed_t;

typedef struct neighbor_s {
    int g_cost;
    int h_cost;
    int f_cost;
    int x_pos;
    int y_pos;
    struct neighbor_s *n;
} neighbor_t;

typedef struct camefrom_s {
    int x_pos;
    int y_pos;
    struct camefrom_s *p;
    struct camefrom_s *n;
} camefrom_t;

typedef struct mv_s {
    int x_pos;
    int y_pos;
    struct mv_s *p;
    struct mv_s *n;
} mv_t;

#endif /* !STRUCT_H_ */
