/*
** EPITECH PROJECT, 2024
** ASM
** File description:
** ASM
*/

#ifndef _ASM_
    #define _ASM_
    #include <limits.h>
void set_node_open(open_t **list_open, int *data);
void disp_open(open_t *list);
void free_open(open_t *list);
void delete_node(open_t **list);
void set_node_neighbor(neighbor_t **list_neighbor, int *data);
void free_neighbor(neighbor_t *list);
void disp_neighbor(neighbor_t *list);
int is_node_open(open_t *list_open, int x_pos, int y_pos);
void set_node_camefrom(camefrom_t **list_camefrom, int x_s, int y_s, int x_p, int y_p);
void disp_camefrom(camefrom_t *list);
void free_camefrom(camefrom_t *list);
void set_node_closed(closed_t **list_closed, int *data);
void free_closed(closed_t *list);
int is_node_closed(closed_t *list_closed, int x_pos, int y_pos);
void a_star(int x_s, int y_s, int x_g, int y_g, int distance, char **map, mv_t **list_move);
int heuristics_dia(int x_a, int y_a, int x_b, int y_b);
void disp_map(char **map);
void set_node_move(mv_t **list_move, int x, int y);
void free_move(mv_t *list);
#endif /* !_ASM_ */
