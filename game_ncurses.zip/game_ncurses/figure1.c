#include <ncurses.h>
#include <stdlib.h>
#include <time.h>

#define WIDTH 80
#define HEIGHT 40

typedef struct {
    int x, y;
} Position;

Position player;
Position zombies[10];
int num_zombies = 100;

void init_game() {
    srand(time(0));
    player.x = WIDTH / 2;
    player.y = HEIGHT / 2;

    // Spawn zombies at random positions
    for (int i = 0; i < num_zombies; i++) {
        zombies[i].x = rand() % WIDTH;
        zombies[i].y = rand() % HEIGHT;
    }
}

void draw_game() {
    clear();

    // Draw player
    mvaddch(player.y, player.x, '@');

    // Draw zombies
    for (int i = 0; i < num_zombies; i++) {
        mvaddch(zombies[i].y, zombies[i].x, 'Z');
    }

    refresh();
}

void update_game() {
    int ch = getch();
    switch (ch) {
        case KEY_UP:
            player.y = (player.y > 0) ? player.y - 1 : player.y;
            break;
        case KEY_DOWN:
            player.y = (player.y < HEIGHT - 1) ? player.y + 1 : player.y;
            break;
        case KEY_LEFT:
            player.x = (player.x > 0) ? player.x - 1 : player.x;
            break;
        case KEY_RIGHT:
            player.x = (player.x < WIDTH - 1) ? player.x + 1 : player.x;
            break;
    }

    // Update zombies (for now random movement)
    for (int i = 0; i < num_zombies; i++) {
        int move_dir = rand() % 4;
        switch (move_dir) {
            case 0: zombies[i].y = (zombies[i].y > 0) ? zombies[i].y - 1 : zombies[i].y; break;
            case 1: zombies[i].y = (zombies[i].y < HEIGHT - 1) ? zombies[i].y + 1 : zombies[i].y; break;
            case 2: zombies[i].x = (zombies[i].x > 0) ? zombies[i].x - 1 : zombies[i].x; break;
            case 3: zombies[i].x = (zombies[i].x < WIDTH - 1) ? zombies[i].x + 1 : zombies[i].x; break;
        }
    }
}

int main() {
    initscr();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(0);

    init_game();

    while (1) {
        draw_game();
        update_game();
    }

    endwin();
    return 0;
}
