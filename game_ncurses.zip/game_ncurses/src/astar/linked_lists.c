/*
** EPITECH PROJECT, 2024
** MY_NAVY
** File description:
** Function to count number of word in a function
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "../../include/utils.h"
#include "../../include/struct.h"
#include "../../include/robot.h"
#include "../../include/all_linked_list/doubly_linked_list/d_list.h"
#include "../../include/tree/tree.h"
#include <dirent.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <time.h>
#include <stdio.h>
#include <math.h>

void set_node_move(mv_t **list_move, int x, int y)
{
    mv_t *new = malloc(sizeof(mv_t));

    *new = (mv_t) {x, y, (mv_t *)0x0, (mv_t *)0x0};

    if (!(*list_move)) {
        (*list_move) = new;
        return;
    }
    new->n = (*list_move);
    (*list_move)->p = new;
    (*list_move) = new;
    return;
}

void free_move(mv_t *list)
{
    if (!list)
        return;
    while(list) {
        mv_t *tmp = list;
        list = list->n;
        free(tmp);
    }
    return;
}

void set_node_open(open_t **list_open, int *data)
{
    open_t *new = malloc(sizeof(open_t));

    *new = (open_t) {data[0], data[1], data[2], data[3], data[4], data[5], data[6], (open_t *)0x0};

    if (!(*list_open) || (*list_open)->f_cost > data[2]) {
        new->n = (*list_open);
        (*list_open) = new;
        free_f(data);
        return;
    }
    open_t *tmp = (*list_open);
    for(; tmp->n && tmp->n->f_cost < data[2]; tmp = tmp->n);
    new->n = tmp->n;
    tmp->n = new;
    free_f(data);
    return;
}

void delete_node(open_t **list)
{
    open_t *tmp = (*list);

    (*list) = (*list)->n;
    free(tmp);
    return;
}

void disp_open(open_t *list)
{
    open_t *tmp = list;

    if (!list)
        return;
    mini_printf("list_open\n");
    for(; tmp; tmp = tmp->n)
        mini_printf("g_cost: %d\th_cost: %d\tf_cost: %d\tx_pos: %d\ty_pos: %d\n", tmp->g_cost, tmp->h_cost, tmp->f_cost, tmp->x_pos, tmp->y_pos);
    return;
}

void free_open(open_t *list)
{
    if (!list)
        return;
    while(list) {
        open_t *tmp = list;
        list = list->n;
        free(tmp);
    }
    return;
}

void set_node_neighbor(neighbor_t **list_neighbor, int *data)
{
    neighbor_t *new = malloc(sizeof(neighbor_t));

    *new = (neighbor_t) {data[0], data[1], data[2], data[3], data[4], (neighbor_t *)0x0};

    if (!(*list_neighbor)) {
        new->n = (*list_neighbor);
        (*list_neighbor) = new;
        return;
    }
    neighbor_t *tmp = (*list_neighbor);
    for(; tmp->n; tmp = tmp->n);
    tmp->n = new;
    return;
}

void free_neighbor(neighbor_t *list)
{
    if (!list)
        return;
    while(list) {
        neighbor_t *tmp = list;
        list = list->n;
        free(tmp);
    }
    return;
}

void disp_neighbor(neighbor_t *list)
{
    neighbor_t *tmp = list;

    if (!list)
        return;
    mini_printf("list_neighbor\n");
    for(; tmp; tmp = tmp->n)
        mini_printf("g_cost: %d\th_cost: %d\tf_cost: %d\tx_pos: %d\ty_pos: %d\n", tmp->g_cost, tmp->h_cost, tmp->f_cost, tmp->x_pos, tmp->y_pos);
    return;
}

int is_node_open(open_t *list_open, int x_pos, int y_pos)
{
    open_t *tmp = list_open;

    for(; tmp; tmp = tmp->n)
        if (tmp->x_pos == x_pos && tmp->y_pos == y_pos)
            return 1;
    return 0;
}

int is_node_closed(closed_t *list_closed, int x_pos, int y_pos)
{
    closed_t *tmp = list_closed;

    for(; tmp; tmp = tmp->n)
        if (tmp->x_pos == x_pos && tmp->y_pos == y_pos)
            return 1;
    return 0;
}

void set_node_camefrom(camefrom_t **list_camefrom, int x_s, int y_s, int x_p, int y_p)
{

    camefrom_t *new = malloc(sizeof(camefrom_t));
    *new = (camefrom_t) {x_s, y_s, (camefrom_t *)0x0, (camefrom_t *)0x0};

    if (!(*list_camefrom)) {
        (*list_camefrom) = new;
        return;
    }
    camefrom_t *tmp2 = (*list_camefrom);
    for(; tmp2; tmp2 = tmp2->n)
        if (tmp2->x_pos == x_p && tmp2->y_pos == y_p) {
            *new = (camefrom_t) {x_s, y_s, tmp2, (*list_camefrom)};
            (*list_camefrom) = new;
            return;
        }
    camefrom_t *prev = malloc(sizeof(camefrom_t));
    *prev = (camefrom_t) {x_p, y_p, (camefrom_t *)0x0, (camefrom_t *)0x0};
    *new = (camefrom_t) {x_s, y_s, prev, (*list_camefrom)};
    (*list_camefrom) = new;
    return;
}

void disp_camefrom(camefrom_t *list)
{
    camefrom_t *tmp = list;

    if (!list)
        return;
    mini_printf("list_camefrom\n");
    for(; tmp; tmp = tmp->n) {
        mini_printf("x_pos: %d\ty_pos: %d\n", tmp->x_pos, tmp->y_pos);
        camefrom_t *tmp2 = tmp;
        for(; tmp2; tmp2 = tmp2->p)
            if (tmp2->p)
                mini_printf("x_prev: %d\ty_prev: %d\n", tmp2->p->x_pos, tmp2->p->y_pos);
        mini_printf("\n");
    }
    return;
}

void free_camefrom(camefrom_t *list)
{
    if (!list)
        return;
    while(list) {
        camefrom_t *tmp = list;
        list = list->n;
        free(tmp);
    }
    return;
}

void set_node_closed(closed_t **list_closed, int *data)
{
    closed_t *new = malloc(sizeof(closed_t));

    *new = (closed_t) {data[0], data[1], (closed_t *)0x0};

    if (!(*list_closed)) {
        (*list_closed) = new;
        return;
    }
    new->n = (*list_closed);
    (*list_closed) = new;
    return;
}

void free_closed(closed_t *list)
{
    if (!list)
        return;
    while(list) {
        closed_t *tmp = list;
        list = list->n;
        free(tmp);
    }
    return;
}
