/*
** EPITECH PROJECT, 2024
** MY_NAVY
** File description:
** Function to count number of word in a function
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "../include/utils.h"
#include "../include/struct.h"
#include "../include/robot.h"
#include "../include/all_linked_list/doubly_linked_list/d_list.h"
#include "../include/tree/tree.h"
#include <dirent.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <time.h>
#include <stdio.h>
#include <math.h>
#include <ncurses.h>

#define RED     "\x1b[31m"
#define GREEN   "\x1b[32m"
#define YELLOW  "\x1b[33m"
#define BLUE    "\x1b[34m"
#define MAGENTA "\x1b[35m"
#define CYAN    "\x1b[36m"
#define RESET   "\x1b[0m"

void disp_line_ncurses(char *line)
{
    start_color();
    init_pair(1, COLOR_BLUE, COLOR_BLACK);
    init_pair(2, COLOR_RED, COLOR_BLACK);
    init_pair(3, COLOR_GREEN, COLOR_BLACK);
    init_pair(4, COLOR_YELLOW, COLOR_BLACK);
    init_pair(5, COLOR_YELLOW, COLOR_BLACK);
    init_pair(6, COLOR_MAGENTA, COLOR_BLACK);

    for(int x = 0; line[x]; x++) {
        if (line[x] == '.') {
            attron(COLOR_PAIR(1));
            printw("%c", line[x]);
            attroff(COLOR_PAIR(1));
        }
        if (line[x] == 'o') {
            attron(COLOR_PAIR(2));
            printw("%c", line[x]);
            attroff(COLOR_PAIR(2));
        }
        if (line[x] == '#') {
            attron(COLOR_PAIR(1));
            printw("%c", line[x]);
            attroff(COLOR_PAIR(1));
        }
        if (line[x] == 'x') {
            attron(COLOR_PAIR(4));
            printw("%c", line[x]);
            attroff(COLOR_PAIR(4));
        }
        if (line[x] == '*' || line[x] == 'M') {
            attron(COLOR_PAIR(2));
            printw("%c", line[x]);
            attroff(COLOR_PAIR(2));
        }
        if (line[x] == '+') {
            attron(COLOR_PAIR(6));
            printw("%c", line[x]);
            attroff(COLOR_PAIR(6));
        }
        if (line[x] == ' ') {
            printw("%c", line[x]);
        }
        if (!line[x + 1])
            printw("\n");
    }
}

void disp_map_ncurses(char **map)
{
    for(int x = 0; map[x]; x++)
        disp_line_ncurses(map[x]);
    return;
}

int main(int ac, char **av)
{
    if (ac != 2)
        return 84;
    int fd = fs_open_file(av[1]);
    char *content = read_map(fd, av[1]);
    char **map = split(content, "\n");
    int *data_pose = malloc(sizeof(int) * 4);
    for(int x = 0; map[x]; x++)
        for(int y = 0; map[x][y]; y++) {
            map[x][y] == '*' ? data_pose[0] = x : data_pose[0];
            map[x][y] == '*' ? data_pose[1] = y : data_pose[1];
            map[x][y] == 'x' ? data_pose[2] = x : data_pose[2];
            map[x][y] == 'x' ? data_pose[3] = y : data_pose[3];
        }
    int distance_target = heuristics_dia(data_pose[0], data_pose[1], data_pose[2], data_pose[3]);
    mv_t *list_move = (mv_t *)0x0;
    a_star(data_pose[0], data_pose[1], data_pose[2], data_pose[3], distance_target, map, &list_move);
    initscr();
    curs_set(FALSE);
    mv_t *tmp_move = list_move;
    for(; tmp_move; tmp_move = tmp_move->n) {
        if (tmp_move->p && tmp_move->p->p && tmp_move->p->p->p)
            map[tmp_move->p->p->p->x_pos][tmp_move->p->p->p->y_pos] = ' ';
        if (tmp_move->p && tmp_move->p->p)
            map[tmp_move->p->p->x_pos][tmp_move->p->p->y_pos] = '*';
        if (tmp_move->p)
            map[tmp_move->p->x_pos][tmp_move->p->y_pos] = '*';
        // if (tmp_move->p)
        //     map[tmp_move->p->x_pos][tmp_move->p->y_pos] = ' ';
        // map[tmp_move->x_pos][tmp_move->y_pos] = 'M';
        map[tmp_move->x_pos][tmp_move->y_pos] = '*';
        // mini_printf("*: %d-%d\n", tmp_move->x_pos, tmp_move->y_pos);
        map[data_pose[2]][data_pose[3]] = 'x';
        disp_map_ncurses(map);
        refresh();
        usleep(100000);
        erase();
    }
    usleep(500000);
    endwin();
    // disp_tab(map);
    free_move(list_move);
    free_f(data_pose);
    free_f(content);
    free_2d_array(map);
    return 0;
}
