#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

// #define CONNECTION_HOST "127.0.0.1"
#define CONNECTION_HOST "172.20.250.203"
#define LISENING_PORT 30000
#define PENDING_QUEUE_MAXLENGTH 1
#define BUFFER_SIZE 1024


int main(int ac, char **av)
{
    int socket_fd = socket(AF_INET, SOCK_STREAM, 0);

    if (socket_fd == -1) {
        fprintf(stderr, "(SERVER) failed initialisation socket\n");
        exit(84);
    }
    struct sockaddr_in socket_address;
    socket_address.sin_family = AF_INET;
    socket_address.sin_port = htons(LISENING_PORT);
    // socket_address.sin_addr.s_addr = INADDR_ANY;
    socket_address.sin_addr.s_addr = inet_addr(CONNECTION_HOST);
    int socket_address_length = sizeof(socket_address);

    int bind_return_code = bind(socket_fd, (struct sockaddr *) &socket_address, socket_address_length);

    if (bind_return_code == -1) {
        fprintf(stderr, "(SERVER) failed linking socket\n");
        exit(84);
    }
    if (listen(socket_fd, PENDING_QUEUE_MAXLENGTH)) {
        fprintf(stderr, "(SERVER) failed starting listening connections socket\n");
        exit(84);
    }
    while(1) {
        printf("waiting for connection ...\n");
        int connected_socketFD = accept(socket_fd, (struct sockaddr *) &socket_address, (socklen_t *) &socket_address_length);

        if (connected_socketFD == -1) {
            fprintf(stderr, "(SERVER) failed accept address socket\n");
            exit(84);
        }
        char buffer[BUFFER_SIZE] = {0};
        int receive_bytes = recv(connected_socketFD, buffer, BUFFER_SIZE, 0);

        if (receive_bytes == -1) {
            fprintf(stderr, "(SERVER) failed reception socket\n");
            exit(84);
        }
        const char message[] = "Welcome client\n";
        int send_byte = send(connected_socketFD, message, strlen(message), 0);
            if (send_byte == -1) {
            fprintf(stderr, "(SERVER) failed send message socket\n");
            exit(84);
        }
        printf("%s\n", buffer);
        close(connected_socketFD);
    }
    close(socket_fd);
    return 0;
}
