/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** epitech
*/

#include "my.h"

l_aminoacid_t *tmp;
l_aminoacid_t *tmp2;
l_aminoacid_t *new;

void insert_sorted_amino_acid(l_aminoacid_t **list,
    char *amino_acid)
{
    tmp = NULL;
    new = malloc(sizeof(l_aminoacid_t));
    tmp2 = (*list);

    for (; tmp2; tmp2 = tmp2->n)
        if (!strcmp(tmp2->aminoacid, amino_acid))
            return;
    *new = (l_aminoacid_t){amino_acid, (l_aminoacid_t *)0x0};
    if (!(*list) || strcmp((*list)->aminoacid, amino_acid) > 0) {
        new->n = (*list);
        (*list) = new;
        return;
    }
    tmp = (*list);
    for (; tmp->n && strcmp(tmp->n->aminoacid,
    amino_acid) < 0; tmp = tmp->n);
    new->n = tmp->n;
    tmp->n = new;
    return;
}

char *amino_acid(char *coding_sequence)
{
    char *coding = NULL;
    char *coding_seq = strdup(coding_sequence);
    int len = strlen(coding_seq);
    char *amino = malloc(sizeof(char) * ((len / 3) + 1));
    int x = 0;

    for (; coding_seq && strlen(coding_seq) > 2; coding_seq += 3) {
        coding = malloc(sizeof(char) * 4);
        coding = strncpy(coding, coding_seq, 3);
        coding[3] = 0;
        amino[x] = letters_amino_acid(coding);
        free(coding);
        x++;
    }
    amino[x] = 0;
    return amino;
}

void disp_listsorted_aminoacid(l_aminoacid_t *list)
{
    l_aminoacid_t *tmp = list;

    if (!tmp)
        return;
    for (; tmp; tmp = tmp->n)
        printf("%s\n", tmp->aminoacid);
    return;
}

void disp_aminoacids_fasta(fasta_t *list_fasta)
{
    char *amino = NULL;
    char *seq = NULL;
    fasta_t *tmp = NULL;
    l_cod_seq *list_codingsequence = NULL;
    l_cod_seq *tmp2 = NULL;
    l_aminoacid_t *list_aminoacid = NULL;

    if (!list_fasta)
        return;
    tmp = list_fasta;
    for (; tmp; tmp = tmp->next) {
        seq = strdup(tmp->final_seq);
        find_codingsequence(seq, &list_codingsequence);
    }
    tmp2 = list_codingsequence;
    for (; tmp2; tmp2 = tmp2->n) {
        amino = amino_acid(tmp2->codingsequence);
        insert_sorted_amino_acid(&list_aminoacid, amino);
    }
    disp_listsorted_aminoacid(list_aminoacid);
}
