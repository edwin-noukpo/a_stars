/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** coding
*/

#include "my.h"

void disp_codingsequence_fasta(fasta_t *list_fasta)
{
    char *seq = NULL;
    fasta_t *tmp = NULL;
    l_cod_seq *list = (l_cod_seq *)0x0;

    if (!list_fasta)
        return;
    tmp = list_fasta;
    for (; tmp; tmp = tmp->next) {
        seq = strdup(tmp->final_seq);
        find_codingsequence(seq, &list);
    }
    disp_listsorted_codingsequence(list);
    free_list_codingsequence(list);
    return;
}

void free_list_codingsequence(l_cod_seq *list)
{
    l_cod_seq *tmp = list;

    while (list) {
        tmp = list;
        list = list->n;
        free(tmp->codingsequence);
        free(tmp);
    }
}

void insert_sorted_codingsequence(l_cod_seq **list,
    char *seq_cod)
{
    l_cod_seq *new = malloc(sizeof(l_cod_seq));
    l_cod_seq *tmp = (l_cod_seq *)0x0;
    l_cod_seq *tmp2 = (*list);

    if (!new || !seq_cod)
        return;
    for (; tmp2; tmp2 = tmp2->n)
        if (!strcmp(tmp2->codingsequence, seq_cod))
            return;
    *new = (l_cod_seq){seq_cod, (l_cod_seq *)0x0};
    if (!(*list) || strcmp((*list)->codingsequence, seq_cod) > 0) {
        new->n = (*list);
        (*list) = new;
        return;
    }
    tmp = (*list);
    for (; tmp->n && strcmp(tmp->n->codingsequence,
    seq_cod) < 0; tmp = tmp->n);
    new->n = tmp->n;
    tmp->n = new;
    return;
}
