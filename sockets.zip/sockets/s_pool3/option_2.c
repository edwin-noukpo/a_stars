/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** coding
*/

#include "my.h"

char *rna(char *molecules)
{
    for (int i = 0; molecules[i]; i++)
        if (molecules[i] == 'T')
            molecules[i] = 'U';
    return molecules;
}

void disp_rna_fasta(fasta_t *list)
{
    fasta_t *tmp = NULL;
    char *seq = (char *)0x0;

    if (!list)
        return;
    tmp = list;
    while (tmp != NULL) {
        printf("%s\n", tmp->identifier);
        seq = rna(strdup(tmp->final_seq));
        color_adn(seq);
        free(seq);
        tmp = tmp->next;
    }
}

int n_codon(char *codon)
{
    for (int x = 0; codon[x]; x++)
        if (codon[x] == 'N')
            return 0;
    return 1;
}
