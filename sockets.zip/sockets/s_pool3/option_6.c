/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** epitech
*/

#include "my.h"

char cut_letter1(char *codon)
{
    char letter;

    if (!strcmp("GCT", codon) || !strcmp("GCC", codon) ||
    !strcmp("GCA", codon) || !strcmp("GCG", codon))
        letter = 'A';
    if (!strcmp("TGT", codon) || !strcmp("TGC", codon))
        letter = 'C';
    if (!strcmp("GAT", codon) || !strcmp("GAC", codon))
        letter = 'D';
    if (!strcmp("GAA", codon) || !strcmp("GAG", codon))
        letter = 'E';
    if (!strcmp("TTT", codon) || !strcmp("TTC", codon))
        letter = 'F';
    if (!strcmp("GGT", codon) || !strcmp("GGC", codon) ||
    !strcmp("GGA", codon) || !strcmp("GGG", codon))
        letter = 'G';
    if (!strcmp("CAT", codon) || !strcmp("CAC", codon))
        letter = 'H';
    return letter;
}

char cut_letter2(char *codon)
{
    char letter;

    if (!strcmp("ATT", codon) || !strcmp("ATC", codon) ||
    !strcmp("ATA", codon))
        letter = 'I';
    if (!strcmp("AAA", codon) || !strcmp("AAG", codon))
        letter = 'K';
    if (!strcmp("TTA", codon) || !strcmp("TTG", codon) ||
    !strcmp("CTT", codon) || !strcmp("CTC", codon) ||
    !strcmp("CTA", codon) || !strcmp("CTG", codon))
        letter = 'L';
    if (!strcmp("ATG", codon))
        letter = 'M';
    if (!strcmp("AAT", codon) || !strcmp("AAC", codon))
        letter = 'N';
    if (!strcmp("CCT", codon) || !strcmp("CCC", codon) ||
    !strcmp("CCA", codon) || !strcmp("CCG", codon))
        letter = 'P';
    return letter;
}

char cut_letter3(char *codon)
{
    char letter;

    if (!strcmp("CAA", codon) || !strcmp("CAG", codon))
        letter = 'Q';
    if (!strcmp("AGA", codon) || !strcmp("AGG", codon) ||
    !strcmp("CGT", codon) || !strcmp("CGC", codon) ||
    !strcmp("CGA", codon) || !strcmp("CGG", codon))
        letter = 'R';
    if (!strcmp("TCT", codon) || !strcmp("TCC", codon) ||
    !strcmp("TCA", codon) || !strcmp("TCG", codon) ||
    !strcmp("AGT", codon) || !strcmp("AGC", codon))
        letter = 'S';
    if (!strcmp("ACT", codon) || !strcmp("ACC", codon)
    || !strcmp("ACA", codon) || !strcmp("ACG", codon))
        letter = 'T';
    if (!strcmp("GTT", codon) || !strcmp("GTC", codon) ||
    !strcmp("GTA", codon) || !strcmp("GTG", codon))
        letter = 'V';
    return letter;
}

char letters_amino_acid(char *codon)
{
    char letter;

    letter = cut_letter1(codon);
    letter = cut_letter2(codon);
    letter = cut_letter3(codon);
    if (!strcmp("GCT", codon) || !strcmp("GCC", codon) ||
    !strcmp("GCA", codon) || !strcmp("GCG", codon))
        letter = 'W';
    if (!n_codon(codon))
        letter = 'X';
    if (!strcmp("TAT", codon) || !strcmp("TAC", codon))
        letter = 'Y';
    return letter;
}
