/*
** EPITECH PROJECT, 2024
** eninla
** File description:
** yafoy
*/

#include "my.h"

void add_sequence(seq_t **list_seq, char *sequence)
{
    seq_t *new = malloc(sizeof(seq_t));
    seq_t *tmp = NULL;

    if (!new || !sequence || !*sequence)
        return;
    new->sequence = strdup(sequence);
    new->next = NULL;
    if (*list_seq == NULL) {
        *list_seq = new;
        return;
    }
    tmp = (*list_seq);
    for (; tmp->next; tmp = tmp->next);
    tmp->next = new;
    return;
}

void add_fasta(fasta_t **list_fasta, char *identifier,
    seq_t *list_seq, char *final_seq)
{
    fasta_t *copy = NULL;
    fasta_t *node = malloc(sizeof(fasta_t));

    if (!node)
        return;
    node->identifier = strdup(identifier);
    node->all_seqs = list_seq;
    node->final_seq = strdup(final_seq);
    node->next = NULL;
    if (*list_fasta == NULL) {
        *list_fasta = node;
        return;
    }
    copy = (*list_fasta);
    while (copy->next != NULL) {
        copy = copy->next;
    }
    copy->next = node;
    return;
}
