/*
** EPITECH PROJECT, 2024
** option
** File description:
** coding
*/

#include "my.h"

void free_list_seq(seq_t *list)
{
    seq_t *tmp = NULL;

    while (list) {
        tmp = list;
        list = list->next;
        free(tmp->sequence);
        free(tmp);
    }
}

void free_fasta(fasta_t *list_fasta)
{
    fasta_t *tmp = (fasta_t *)0x0;

    if (!list_fasta)
        return;
    while (list_fasta) {
        tmp = list_fasta;
        list_fasta = list_fasta->next;
        free(tmp->identifier);
        free_list_seq(tmp->all_seqs);
        free(tmp->final_seq);
        free(tmp);
    }
}

char *clear_seq(char *str)
{
    int j = 0;
    char *src = malloc(sizeof(char) * (strlen(str) + 1));

    for (int i = 0; str[i] != '\0'; i++) {
        if (!is_molecules(str[i])) {
            src[j] = str[i];
            j++;
        }
    }
    src[j] = '\0';
    return src;
}

char *assembly_seq(seq_t *list_seq)
{
    seq_t *tmp = list_seq;
    int total_length = 0;
    char *final_seq = (char *)0x0;

    for (; tmp; tmp = tmp->next)
        total_length += strlen(tmp->sequence);
    final_seq = malloc(sizeof(char) * (total_length + 1));
    if (!final_seq)
        return (char *)0x0;
    *final_seq = 0;
    tmp = list_seq;
    for (; tmp; tmp = tmp->next)
        strcat(final_seq, tmp->sequence);
    return final_seq;
}

void disp_fasta(fasta_t *list)
{
    fasta_t *tmp = NULL;

    if (!list)
        return;
    tmp = list;
    while (tmp != NULL) {
        printf("%s\n", tmp->identifier);
        color_adn(tmp->final_seq);
        tmp = tmp->next;
    }
}
