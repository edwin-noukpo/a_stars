/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** coding
*/

#include "my.h"

void free_list_kmer(l_kmer_t *list)
{
    l_kmer_t *tmp = NULL;

    while (list) {
        tmp = list;
        list = list->n;
        free(tmp->kmer);
        free(tmp);
    }
}

void insert_sorted(l_kmer_t **list, char *sequence_kmer)
{
    l_kmer_t *new = malloc(sizeof(l_kmer_t));
    l_kmer_t *tmp = (l_kmer_t *)0x0;
    l_kmer_t *tmp2 = (*list);

    if (!new || !sequence_kmer)
        return;
    for (; tmp2; tmp2 = tmp2->n)
        if (!strcmp(tmp2->kmer, sequence_kmer))
            return;
    *new = (l_kmer_t) {sequence_kmer, (l_kmer_t *)0x0};
    if (!(*list) || strcmp((*list)->kmer, sequence_kmer) > 0) {
        new->n = (*list);
        (*list) = new;
        return;
    }
    tmp = (*list);
    for (; tmp->n && strcmp(tmp->n->kmer,
    sequence_kmer) < 0; tmp = tmp->n);
    new->n = tmp->n;
    tmp->n = new;
    return;
}

void disp_listsorted_kmer(l_kmer_t *list)
{
    l_kmer_t *tmp = list;

    if (!tmp)
        return;
    for (; tmp; tmp = tmp->n)
        color_adn(tmp->kmer);
    return;
}

void find_kmer(char *seq, int k, l_kmer_t **list)
{
    char *new = NULL;

    if (!seq || !*seq || !k || strlen(seq) < k)
        return;
    new = malloc(sizeof(char) * (k + 1));
    new = strncpy(new, seq, k);
    new[k] = 0;
    insert_sorted(&(*list), new);
    seq += 1;
    find_kmer(seq, k, &(*list));
    return;
}

void disp_kmer_fasta(fasta_t *list_fasta, int k)
{
    char *seq = NULL;
    fasta_t *tmp = NULL;
    l_kmer_t *list_kmer = (l_kmer_t *)0x0;

    if (!list_fasta)
        return;
    tmp = list_fasta;
    while (tmp != NULL) {
        seq = strdup(tmp->final_seq);
        find_kmer(seq, k, &list_kmer);
        tmp = tmp->next;
        free(seq);
    }
    disp_listsorted_kmer(list_kmer);
    free_list_kmer(list_kmer);
}
