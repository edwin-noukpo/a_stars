/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** coding
*/

#include "my.h"

char *final_seq;
char *identifier;
char *buffer;
fasta_t *list_fasta;
seq_t *list_seq;

char *read_line(void)
{
    char *buffer = NULL;
    size_t size = 0;
    ssize_t len = getline(&buffer, &size, stdin);

    if (len == -1) {
        free(buffer);
        return NULL;
    }
    buffer[len - 1] = '\0';
    return buffer;
}

int each_case(fasta_t *list_fasta, char **av)
{
    if (!atoi(av[1]) || atoi(av[1]) > 6)
        return 84;
    if (!strcmp(av[1], "1") && !av[2])
        disp_fasta(list_fasta);
    if (!strcmp(av[1], "2") && !av[2])
        disp_rna_fasta(list_fasta);
    if (!strcmp(av[1], "3") && !av[2])
        disp_reversecomplement_fasta(list_fasta);
    if (!strcmp(av[1], "4") && av[2])
        disp_kmer_fasta(list_fasta, atoi(av[2]));
    if (!strcmp(av[1], "5") && !av[2])
        disp_codingsequence_fasta(list_fasta);
    if (!strcmp(av[1], "6") && !av[2])
        disp_aminoacids_fasta(list_fasta);
}

void cut_insert_concat(char **buffer)
{
    for (*buffer = read_line(); *buffer && check_identifier(*buffer);
    *buffer = read_line()) {
        *buffer = upper_case(*buffer);
        *buffer = clear_seq(*buffer);
        add_sequence(&list_seq, *buffer);
    }
}

void insert_concat(void)
{
    while (buffer) {
        buffer = clear_string(buffer);
        if (!check_identifier(buffer)) {
            identifier = strdup(buffer);
            list_seq = NULL;
            cut_insert_concat(&buffer);
        }
        final_seq = assembly_seq(list_seq);
        final_seq = strdup(final_seq);
        add_fasta(&list_fasta, identifier, list_seq, final_seq);
    }
}

int main(int ac, char **av)
{
    buffer = NULL;
    final_seq = NULL;
    identifier = NULL;
    list_fasta = NULL;
    list_seq = NULL;
    if (ac == 1)
        return 84;
    buffer = read_line();
    insert_concat();
    free(buffer);
    each_case(list_fasta, av);
    free_fasta(list_fasta);
}
