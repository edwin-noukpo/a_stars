/*
** EPITECH PROJECT, 2024
** merci
** File description:
** bcp
*/

#include <stdlib.h>
#include <unistd.h>

int my_strlen(char *str)
{
    int i = 0;

    for (i = 0; str[i] != '\0'; i++);
    return i;
}

char majuscule(char c)
{
    if (c >= 'a' && c <= 'z')
        c = c - 32;
    return c;
}

int isalphanum(char c)
{
    if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') ||
        (c >= 'A' && c <= 'Z'))
        return 0;
    return 1;
}

char *function(char *str)
{
    int k = 0;

    for (int i = 0; str[i] != '\0'; i++) {
        str[0] = majuscule(str[0]);
        if (isalphanum(str[i]) == 1 && isalphanum(str[i + 1] == 0))
            str[i + 1] = majuscule(str[i + 1]);
    }
    write(1, str, my_strlen(str));
    write(1, "\n", 1);
    return str;
}

int main(int ac, char **av)
{
    char *str = function(av[1]);
}
