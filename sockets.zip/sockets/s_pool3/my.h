/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** epitech
*/

#ifndef MY_H
    #define MY_H
    #include <stdio.h>
    #include <stdlib.h>
    #include <unistd.h>
    #include <string.h>
    #include <fcntl.h>
    #include <sys/stat.h>

typedef struct seq_s {
    char *sequence;
    struct seq_s *next;
} seq_t;

typedef struct fasta_s {
    char *identifier;
    seq_t *all_seqs;
    char *final_seq;
    char *aminos_acids;
    struct fasta_s *next;
} fasta_t;

typedef struct l_codingsequence_s {
    char *codingsequence;
    struct l_codingsequence_s *n;
} l_cod_seq;

typedef struct l_aminoacid_s {
    char *aminoacid;
    struct l_aminoacid_s *n;
} l_aminoacid_t;

typedef struct l_kmer_s {
    char *kmer;
    struct l_kmer_s *n;
} l_kmer_t;
extern char *final_seq;
extern char *identifier;
extern fasta_t *list_fasta;
extern char *buffer;
extern seq_t *list_seq;


char majuscule(char str);
char *clear_string(char *str);
void free_list_seq(seq_t *list);
void free_list_seq(seq_t *list);
void free_fasta(fasta_t *list_fasta);
char *clear_seq(char *str);
char *assembly_seq(seq_t *list_seq);
void disp_fasta(fasta_t *list);
char *rna(char *molecules);
void disp_rna_fasta(fasta_t *list);
char *reversecomplement(char *molecules);
void disp_reversecomplement_fasta(fasta_t *list);
void free_list_kmer(l_kmer_t *list);
int n_codon(char *codon);
void insert_sorted(l_kmer_t **list, char *sequence_kmer);
void disp_listsorted_kmer(l_kmer_t *list);
void find_kmer(char *seq, int k, l_kmer_t **list);
void disp_kmer_fasta(fasta_t *list_fasta, int k);
int is_codon_stop(char *codon_stop);
void find_codingsequence(char *seq, l_cod_seq **list);
void disp_listsorted_codingsequence(l_cod_seq *list);
void disp_codingsequence_fasta(fasta_t *list_fasta);
void free_list_codingsequence(l_cod_seq *list);
void insert_sorted_codingsequence(l_cod_seq **list,
    char *seq_cod);
char letters_amino_acid(char *codon);
void insert_sorted_amino_acid(l_aminoacid_t **list,
    char *amino_acid);
char *amino_acid(char *coding_sequence);
void disp_listsorted_aminoacid(l_aminoacid_t *list);
void disp_aminoacids_fasta(fasta_t *list_fasta);
void color_adn(char *seq);
int is_molecules(char molecules);
int check_identifier(char *identifier);
char *upper_case(char *molecules);
char *read_line(void);
void add_sequence(seq_t **list_seq, char *sequence);
void add_fasta(fasta_t **list_fasta, char *identifier,
    seq_t *list_seq, char *final_seq);
#endif
