/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** coding
*/

#include "my.h"

void cut_reverse(char *molecules)
{
    for (int i = 0; molecules[i]; i++) {
        if (molecules[i] == 'A') {
            molecules[i] = 'T';
            continue;
        }
        if (molecules[i] == 'T') {
            molecules[i] = 'A';
            continue;
        }
        if (molecules[i] == 'G') {
            molecules[i] = 'C';
            continue;
        }
        if (molecules[i] == 'C') {
            molecules[i] = 'G';
            continue;
        }
    }
}

char *reversecomplement(char *molecules)
{
    char temp;
    int n = strlen(molecules);

    for (int i = 0; i < n / 2; i++) {
        temp = molecules[i];
        molecules[i] = molecules[n - i - 1];
        molecules[n - i - 1] = temp;
    }
    for (int i = 0; molecules[i]; i++)
        cut_reverse(molecules);
    return molecules;
}

void disp_reversecomplement_fasta(fasta_t *list)
{
    fasta_t *tmp = NULL;
    char *seq = (char *)0x0;

    if (!list)
        return;
    tmp = list;
    while (tmp != NULL) {
        printf("%s\n", tmp->identifier);
        seq = reversecomplement(strdup(tmp->final_seq));
        color_adn(seq);
        free(seq);
        tmp = tmp->next;
    }
}
