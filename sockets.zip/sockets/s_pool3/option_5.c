/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** epitech
*/

#include "my.h"

int is_codon_stop(char *codon_stop)
{
    char *tab_codon_stop[] = {"TAA", "TAG", "TGA", NULL};

    for (int x = 0; tab_codon_stop[x]; x++) {
        if (!strcmp(codon_stop, tab_codon_stop[x]))
            return 0;
    }
    return 1;
}

// int find_suite(char *coding, char *co, int k)
// {
//     if (is_codon_stop(coding))
//     co = strcat(co, coding);
//     if (!is_codon_stop(coding)) {
// 	k = 1;
// 	break;
//     }
//     return 2;
// }

void find_codingsequence(char *seq, l_cod_seq **list)
{
    int k = 0;
    char *co = NULL;
    char *coding_seq = NULL;
    char *start_codon = "ATG";
    char *coding = NULL;

    if (!seq || strlen(seq) < 3)
        return;
    if (!strncmp(start_codon, seq, 3)) {
        coding_seq = strdup(seq);
        co = malloc(sizeof(char) * 1000);
        *co = 0;
        k = 0;
        for (; coding_seq && strlen(coding_seq) > 3; coding_seq += 3) {
            coding = malloc(sizeof(char) * 4);
            coding = strncpy(coding, coding_seq, 3);
            coding[3] = 0;
	        if (is_codon_stop(coding))
                co = strcat(co, coding);
            if (!is_codon_stop(coding)) {
                k = 1;
                break;
		    }
	    // find_suite(coding, co, k);
            free(coding);
        }
        if (k)
            insert_sorted_codingsequence(&(*list), co);
    }
    seq += 1;
    find_codingsequence(seq, &(*list));
    return;
}

void disp_listsorted_codingsequence(l_cod_seq *list)
{
    l_cod_seq *tmp = list;

    if (!tmp)
        return;
    for (; tmp; tmp = tmp->n)
        color_adn(tmp->codingsequence);
    return;
}
