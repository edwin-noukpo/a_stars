/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** coding
*/

#include "my.h"

void color_adn(char *seq)
{
    for (int x = 0; seq[x]; x++) {
        if (seq[x] == 'A')
            printf("%c", seq[x]);
        if (seq[x] == 'C')
            printf("%c", seq[x]);
        if (seq[x] == 'U')
            printf("%c", seq[x]);
        if (seq[x] == 'G')
            printf("%c", seq[x]);
        if (seq[x] == 'T')
            printf("%c", seq[x]);
        if (seq[x] == 'N')
            printf("%c", seq[x]);
        if (!seq[x + 1])
            printf("\n");
    }
}

int is_molecules(char molecules)
{
    if (molecules == 'A' || molecules == 'T' ||
    molecules == 'C' || molecules == 'G' ||
    molecules == 'N')
        return 0;
    return 1;
}

int check_identifier(char *identifier)
{
    if (*identifier == '>')
        return 0;
    return 1;
}

char *upper_case(char *molecules)
{
    for (int i = 0; molecules[i]; i++)
        if (molecules[i] >= 'a' && molecules[i] <= 'z')
            molecules[i] -= 32;
    return molecules;
}
