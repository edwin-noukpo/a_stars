/*
** EPITECH PROJECT, 2024
** file
** File description:
** epitech
*/

#include "my.h"

char *cut(char *src, int j)
{
    if (src[j - 1] == ' ')
        src[j - 1] = '\0';
    else
        src[j] = '\0';
    return src;
}

char *clear_string(char *str)
{
    int j = 0;
    int k = 0;
    char *src = malloc(sizeof(char) * (strlen(str) + 1));

    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] != ' ' && str[i] != '\t') {
            src[j] = str[i];
            j++;
            k = 1;
        }
        if (k == 1 && (str[i] == ' ' || str[i] == '\t')) {
            src[j] = ' ';
            k = 0;
            j++;
        }
    }
    src = cut(src, j);
    return src;
}
