/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** undes
*/
#include "my.h"
char *open_the_map(char *map)
{
    int fd;
    int v = 0;
    char *t = NULL;
    struct stat k;
    int size = 0;

    fd = open(map, O_RDONLY);
    if (fd == -1)
        exit(84);
    stat(map, &k);
    size = k.st_size;
    t = malloc(sizeof(char) * (size + 1));
    v = read(fd, t, size);
    if (v == -1 || v == 0)
        exit(84);
    t[v] = '\0';
    return t;
}
