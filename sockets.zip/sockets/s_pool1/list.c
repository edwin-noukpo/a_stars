/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** epitech
*/

#include "my.h"

void push_table(list_t **list, char *file, char *line)
{
    list_t *copy = (*list);
    list_t *newnode = malloc(sizeof(list_t));

    file += 1;
    newnode->str = strdup(file);
    extract_attribute_names(line, &newnode->attributes);
    sort_attrib(&newnode->attributes);
    newnode->next = NULL;
    if (*list == NULL) {
	*list = newnode;
        return;
    }
    if (check_words_unique(*list, file) == 1)
        return;
    while(copy->next != NULL)
	copy = copy->next;
    copy->next = newnode;
    return;
}

int check_words_unique(list_t *list, char *str)
{
    int i = 1;
    list_t *copy = list;

    while(copy != NULL) {
        if (strcmp(copy->str, str) == 0)
            i++;
        copy = copy->next;
    }
    if (i > 1)
        return 1;
    return 0;
}

void disp_attrib(Node_t *list)
{
    Node_t *copy = list;
    
    while (copy != NULL) {
        printf("--->%s\n", copy->name);
        copy = copy->next;
    }
}

void disp_list(list_t *list)
{
    list_t *copy = list;
    
    while (copy != NULL) {
        printf("%s\n", copy->str);
        disp_attrib(copy->attributes);
        copy = copy->next;
    }
}
