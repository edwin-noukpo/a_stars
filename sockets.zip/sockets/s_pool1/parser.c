/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** ok
*/

#include "my.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

void free_table(char **tab)
{
    for (int i = 0; tab[i]; i++)
	free(tab[i]);
    free(tab);
}

void disp(char **tab)
{
    for (int i = 0; tab[i]; i++) {
	printf("%s\n", tab[i]);
    }
}

int chek_balis(char *str)
{
    char *inf = is_char(str, '<');
    char *sup = is_char(str,'>');
    char *equal = is_char(str, '=');
    if (str[1] == '?')
        return 1;
    if (inf != NULL && sup != NULL && equal != NULL)
	return 0;
    else
	return 1;
}
char is_alpha(char *str)
{
    for (int i = 0; str[i]; i++) {
	if (str[i] >= 'a' && str[i] <= 'z' || str[i] >= 'A' && str[i] <= 'Z')
	    return 1;
    }
    return 0;
}
char *extract_first_word(char *line)
{
    int a = 0;
    int i = 0;
    int j = 0;
    char *tmp = malloc(sizeof(char) * 100);
    while (line[i] == ' ')
        i++;
    if (tmp == NULL)
	return NULL;
    while (line[i] != ' ' && line[i] != '/' && line[i] != '\0') {
        tmp[j] = line[i];
	i++;
	j++;
    }
    tmp[j] = '\0'; 
    return tmp;
}
int main(int ac, char **av)
{
    char **cytosol = NULL;
    value_attrib_t *head = NULL;
    list_t *list = NULL;
    char *file = NULL;
    char **array = NULL;
    char *words = malloc(sizeof(char) * 100);
     
    if (ac < 2)
	return 1;
    file = open_the_map(av[1]);
    array = split(file, "\n");
    if (ac == 2) { 
        for (int i = 0; array[i]; i++)
	    if (chek_balis(array[i]) == 0) {
		words = extract_first_word(array[i]);
		printf("words = %s\n", words);
                push_table(&list, words, array[i]);
	    }
        sort(&list);
        disp_list(list);
    }
    /*if (ac == 4 && strcmp(av[2], "-i") == 0 && strcmp(av[3], "Cytosol") == 0) {
      for (int i = 0; array[i]; i++) {
      if (chek_balis(array[i]) == 0) {
      extract_attributes_values(array[i], &head);
      cytosol = check(&head, cytosol);
      }
      disp_tab(cytosol);
      }
      }*/
}

