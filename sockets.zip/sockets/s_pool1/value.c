#include "my.h"

void add_attrib_value(value_attrib_t **list, char *value)
{
    value_attrib_t *copy = NULL;
    value_attrib_t *newnode = malloc(sizeof(value_attrib_t));
    
    newnode->value = strdup(value);
    newnode->next = NULL;

    if ((*list) == NULL) {
        (*list) = newnode;
        return;
    }
    copy = (*list);
    while (copy->next != NULL) {
        copy = copy->next;
    }
    copy->next = newnode;
}

int is_specific_value(char *value) {
    return (strcmp(value, "Adenosine diphosphate") == 0 ||
            strcmp(value, "Adenosine triphosphate") == 0 ||
            strcmp(value, "Alpha-D-Glucose") == 0 ||
            strcmp(value, "Glucose 6-phosphate") == 0);
}

char **copy_list_in_tab(value_attrib_t **list, char **tab) {
    int i = 0;
    int y = count_nodes_value(list);
    value_attrib_t *copy = *list;
    if (copy == NULL)
        return NULL;
    tab = malloc(sizeof(char *) * (y + 1));
    while (copy != NULL) {
        if (is_specific_value(copy->value)) {
            tab[i] = strdup(copy->value);
            i++;
        }
        copy = copy->next;
    }
    tab[i] = NULL;
    return tab;
}

char **check(value_attrib_t **list, char **tab)
{
    tab = copy_list_in_tab(list, tab);
    tab = sort_tab(tab);
    return tab;
}

void extract_attributes_values(char *str, value_attrib_t **value)
{
    char values[500];
    int len = 0;
    char *start_pos = NULL;
    char *end_pos = NULL;
    char *xml = str;
    
    while ((xml = strchr(xml, '=')) != NULL) {
        start_pos = strchr(xml, '"');
        if (start_pos == NULL)
            break;
        start_pos++; 
        end_pos = strchr(start_pos, '"');
        if (end_pos == NULL) {
            break;
        }
        len = end_pos - start_pos;
        strncpy(values, start_pos, len);
        values[len] = '\0';
        add_attrib_value(value, values);
        xml = end_pos + 1;
    }
}

void print_attributes_values(value_attrib_t ** value)
{
    value_attrib_t *copy = NULL;
    
    if (value == NULL)
        return;
    copy = (*value);
    while (copy != NULL) {
        printf("%s\n", copy->value);
        copy = copy->next;
    }
}

int count_nodes_value(value_attrib_t **list)
{
    int i = 0;
    int len = 0;
    value_attrib_t *copy = (*list);

    for (; copy!= NULL; copy = copy->next)
        len++; 
    return len;
}