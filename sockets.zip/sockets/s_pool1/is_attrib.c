#include "my.h"

int check_uniq_attrib(Node_t *list, char *str)
{
    int i = 1;
    Node_t *copy = NULL;
    
    if (list == NULL)
        return 0;
    copy = list;
    while(copy != NULL) {
        if (strcmp(copy->name, str) == 0)
            i++;
	copy = copy->next;
    }
    if (i > 1)
        return 1;
    return 0;
}
void add_attrib(Node_t **list, char *file)
{
    Node_t *copy = (*list);
    Node_t *newnode = malloc(sizeof(Node_t));

    newnode->name = strdup(file);
    newnode->next = NULL;
    if (*list == NULL) {
	    *list = newnode;
        return;
    }
    if (check_uniq_attrib(*list, file) == 1)
        return;
    while(copy->next != NULL) {
	    copy = copy->next;
    }
    copy->next = newnode;
}

void extract_attribute_names(char *xml, Node_t **head) 
{
    char name[50];
    int len = 0;
    char *ptr = xml;
    char *equal_pos;
    char *start_pos;

    while ((equal_pos = strchr(ptr, '=')) != NULL) {
        start_pos = equal_pos - 1;
        while (start_pos > xml && *start_pos != ' ') {
            start_pos--;
        }
        len = equal_pos - (start_pos + 1);
        strncpy(name, start_pos + 1, len);
        name[len] = '\0';
        add_attrib(head, name);
        ptr = equal_pos + 1;
    }
}

void free_list(Node_t *head) 
{
    Node_t *temp;
    while (head != NULL) {
        temp = head;
        head = head->next;
        free(temp);
    }
}
