#include "my.h" 

int count_nodes_attrib(Node_t **list)
{
    int i = 0;
    int len = 0;
    Node_t *copy = (*list);

    for (i; copy->next != NULL; copy = copy->next)
        len++; 
    return len;
}

Node_t *swap_nodes_attrib(Node_t *p1, Node_t *p2)
{
    p1->next = p2->next;
    p2->next = p1;    
    return p2;
}

void sort_attrib(Node_t **list)
{
    Node_t *p1 = NULL;
    Node_t *p2 = NULL;
    int swap = 0;
    int len = count_nodes_attrib(list);
    
    for (int i = 0; i < len; i++) {
        Node_t **copy = list;
        swap = 0;
        for (int j = 0; j < len - i - 1; j++) {
            p1 = *copy;
            p2 = p1->next;
            if (strcmp(p1->name, p2->name) > 0) {
                *copy = swap_nodes_attrib(p1, p2);
                swap = 1;
            }
            copy = &(*copy)->next;
        }
        if (swap == 0)
            break;
    }
}

int tab_len(char **tab)
{
    int i = 0;
    int j = 0;
    if (tab == NULL)
    return 1;
    for (i = 0; tab [i] != NULL; i++)
        j++;
    return j;
}
char **sort_tab(char **tab)
{
    char *temp;
    int n = tab_len(tab);
    if (tab == NULL)
    return NULL;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - 1; j++) {
            if (strcmp(tab[j], tab[j + 1]) > 0) {
                temp = tab[j];
                tab[j] = tab[j + 1];
                tab[j + 1] = temp; 
            }
        }
    }
    return tab;
}
