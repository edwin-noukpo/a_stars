/*
** EPITECH PROJECT, 2024
** file
** File description:
** epitech
*/

#include "my.h"

char *cut(char *src, int j)
{
    if (src[j - 1] == ' ')
	src[j - 1] = '\0';
    else
        src[j - 1] = '\0';
    return src;
}

char *clear_string(char *str)
{
    int j = 0;
    int k = 0;

    char *src = malloc(sizeof(char) * (strlen(str) + 1));

    for (int i = 0; str[i] != '\0'; i++) {
	if (str[i] != ' ' && str[i] != '\t') {
            src[j] = str[i];
            j++;
            k = 1;
        }
        if (k == 1 && (str[i] == ' ' || str[i] == '\t')) {
            src[j] = ' ';
            k = 0;
	    j++;
        }
    }
    src = cut(src, j);
    return src;
}

int charer(char *str, char c)
{
    for (int i = 0; str[i]; i++) {
	if (str[i] == c)
	    return 1;
    }
    return 0;
}

int count_line(char *str, char *seg)
{
    int i = 0;
    int j = 0;

    while(str[i]) {
	for (i; str[i] && charer(seg, str[i]) == 1; i++);
	if (str[i] && charer(seg, str[i]) == 0)
	    j++;
	for (i; str[i] && charer(seg, str[i]) == 0; i++);
    }
    return j;
}

char **split(char *str, char *seg)
{
    int a = 0;
    int b = 0;
    int k = 0;
    int i = 0;
    int j = 0;
    int len = count_line(str, seg);
    char **tab = malloc(sizeof(char *) * (len + 1));

    for (i = 0; i < len; i++) {
	for (k; charer(seg, str[k]) == 1 && str[k]; k++);
	a = 0;
	b = k;
	for (k; charer(seg, str[k]) == 0 && str[k]; k++)
	    a++;
	tab[i] = malloc(sizeof(char) * (a + 1));
	for (j = 0; j < a; j++) {
	    tab[i][j] = str[b];
	    b++;
	}
	tab[i][j] = '\0';
    }
    tab[i] = NULL;
    return tab;
}
