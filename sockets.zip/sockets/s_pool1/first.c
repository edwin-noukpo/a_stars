/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** bof ok
*/

#include "my.h"

char *is_char(char *str, char c)
{
    for (int i = 0; str[i] != '\0'; i++)
        if (str[i] == c)
            return &str[i];
    return NULL;
}

void disp_tab(char **tab)
{
    if (tab == NULL)
        return;
    printf("List of species in compartment Cytosol\n");
    for (int i = 0; tab[i] != NULL; i++)
        printf("--->%s\n", tab[i]);
}

int count_nodes(list_t **list)
{
    int i = 0;
    int len = 0;

    list_t *copy = NULL;
    if (list == NULL)
        return 1;
    copy = (*list);
    for (i; copy!= NULL; copy = copy->next)
        len++; 
    return len;
}

list_t *swap_nodes(list_t *p1, list_t *p2)
{
    p1->next = p2->next;
    p2->next = p1;    
    return p2;
}

void sort(list_t **list)
{
    list_t *p1 = NULL;
    list_t *p2 = NULL;
    int swap = 0;
    int len = count_nodes(list);

    for (int i = 0; i < len; i++) {
        list_t **copy = list;
        swap = 0;
        for (int j = 0; j < len - i - 1; j++) {
            p1 = *copy;
            p2 = p1->next;
            if (strcmp(p1->str, p2->str) > 0) {
                *copy = swap_nodes(p1, p2);
                swap = 1;
            }
            copy = &(*copy)->next;
        }
        if (swap == 0)
            break;
    }
}
