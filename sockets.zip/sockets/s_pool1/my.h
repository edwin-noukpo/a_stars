/*
** EPITECH PROJECT, 2024
** prototype
** File description:
** function
*/

#ifndef MY_H
    #define MY_H
    #include <string.h>
    #include <errno.h>
    #include <stdarg.h>
    #include <stddef.h>
    #include <unistd.h>
    #include <stdlib.h>
    #include <string.h>
    #include <stdio.h>
    #include <ncurses.h>
    #include <sys/stat.h>
    #include <dirent.h>
    #include <sys/types.h>
    #include <sys/wait.h>
    #include <unistd.h>
    #include <stddef.h>
    #include <stdio.h>
    #include <fcntl.h>
    #include <unistd.h>
    #include <stdlib.h>
    #include <signal.h>

typedef struct Node {
    char *name;
    struct Node *next;
} Node_t;

typedef struct my_struct{
    char *str;
    Node_t *attributes;
    struct my_struct *next;
}list_t;

typedef struct my_struct1{
    char *value;
    struct my_struct1 *next;
}value_attrib_t;

char **check(value_attrib_t **list, char **tab);
int count_nodes_value(value_attrib_t **list);
void print_attributes_values(value_attrib_t ** value);
void extract_attributes_values(char *str, value_attrib_t **value);
void delete(list_t **list, char *st);
int check_words_unique(list_t *list, char *str);
void disp_list(list_t *list);
void disp_attrib(Node_t *list);
char **sort_tab(char **tab);
void push_table(list_t **list, char *file, char *line);
char *clear_string(char *str);
char *open_the_map(char *map);
void sort(list_t **list);
void disp_tab(char **tab);
void sort_attrib(Node_t **list);
char **split(char *str, char *seg);
char *is_char(char *str, char c);
int chek_balis(char *str);
char *open_the_map(char *map);
void add_attrib(Node_t **list, char *file);
void free_list(Node_t *head);
void extract_attribute_names(char *xml, Node_t **head);

#endif
