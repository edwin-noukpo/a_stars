#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

// #define CONNECTION_HOST "127.0.0.1"
#define CONNECTION_HOST "172.20.250.203"
#define LISENING_PORT 30000
#define BUFFER_SIZE 1024


int main(int ac, char **av)
{
    while(1) {
        int socket_fd = socket(AF_INET, SOCK_STREAM, 0);

        if (socket_fd == -1) {
            fprintf(stderr, "(CLIENT) failed initialisation socket\n");
            exit(84);
        }
        struct sockaddr_in socket_address;
        socket_address.sin_family = AF_INET;
        socket_address.sin_port = htons(LISENING_PORT);
        // socket_address.sin_addr.s_addr = INADDR_ANY;
        socket_address.sin_addr.s_addr = inet_addr(CONNECTION_HOST);
        int socket_address_length = sizeof(socket_address);

        int inet_return_code = inet_pton(AF_INET, CONNECTION_HOST, &socket_address.sin_addr);

        if (inet_return_code == -1) {
            fprintf(stderr, "(CLIENT) invalid address\n");
            exit(84);
        }
        int connection_status = connect(socket_fd, (struct sockaddr *) &socket_address, socket_address_length);

        if (connection_status == -1) {
            fprintf(stderr, "(CLIENT) failed connection server\n");
            exit(84);
        }
        const char message[] = "Welcome serveur, I am client\n";
        int send_byte = send(socket_fd, message, strlen(message), 0);
            if (send_byte == -1) {
            fprintf(stderr, "(CLIENT) failed send message socket\n");
            exit(84);
        }
        char buffer[BUFFER_SIZE] = {0};
        int receive_bytes = recv(socket_fd, buffer, BUFFER_SIZE, 0);

        printf("%s\n", buffer);
        if (receive_bytes == -1) {
            fprintf(stderr, "(CLIENT) failed reception socket\n");
            exit(84);
        }
        close(socket_fd);
    }
    return 0;
}
