#include <stdio.h>
#include <string.h>
#include <math.h>

// Fonction pour convertir un nombre dans une base donnée en base 10
int toDecimal(char num[], int base) {
    int len = strlen(num);
    int power = 1; // Base^0
    int decimal = 0;

    // Traiter le nombre à partir du chiffre le moins significatif (de droite à gauche)
    for (int i = len - 1; i >= 0; i--) {
        if (num[i] >= '0' && num[i] <= '9') {
            decimal += (num[i] - '0') * power;
        } else if (num[i] >= 'A' && num[i] <= 'Z') {
            decimal += (num[i] - 'A' + 10) * power;
        } else if (num[i] >= 'a' && num[i] <= 'z') {
            decimal += (num[i] - 'a' + 10) * power;
        }
        power *= base;
    }
    return decimal;
}

// Fonction pour convertir un nombre décimal en une base donnée
void fromDecimal(int num, int base, char result[]) {
    int index = 0;
    char digits[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    while (num > 0) {
        result[index++] = digits[num % base];
        num /= base;
    }
    result[index] = '\0';

    // Inverser la chaîne pour obtenir le résultat correct
    int len = strlen(result);
    for (int i = 0; i < len / 2; i++) {
        char temp = result[i];
        result[i] = result[len - i - 1];
        result[len - i - 1] = temp;
    }
}

int main() {
    char num1[20], num2[20], result[20];
    int base;

    printf("Entrez la base : ");
    scanf("%d", &base);

    printf("Entrez le premier nombre : ");
    scanf("%s", num1);

    printf("Entrez le deuxième nombre : ");
    scanf("%s", num2);

    // Convertir les deux nombres en base 10
    int dec1 = toDecimal(num1, base);
    int dec2 = toDecimal(num2, base);

    // Additionner les deux nombres en base 10
    int sum = dec1 + dec2;

    // Convertir la somme en la base d'origine
    fromDecimal(sum, base, result);

    printf("Le résultat de l'addition est : %s\n", result);

    return 0;
}
