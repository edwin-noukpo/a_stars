/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** epi
*/

#include "struct.h"

int temp;
int length;

int is_integer(char *str)
{
    int i = 0;

    if (str == NULL || str[0] == ' ')
        return 1;
    while (str[i]) {
        if ((str[i] >= '0' && str[i] <= '9'))
            i++;
        else
            return 1;
    }
    return 0;
}

int convert_base_to_dec(int binary, int base)
{
    int decimal = 0;
    int pos = 1;

    while (binary > 0) {
        if (binary % 10 == 1) {
            decimal += pos;
        }
        binary /= 10;
        pos *= base;
    }
    return decimal;
}

char *convert_dec_to_base(int nb, int base)
{
    char *result = NULL;

    if (nb < 0)
        return NULL;
    if (base == 0)
        return NULL;
    temp = nb;
    length = 0;
    while (temp > 0) {
        length++;
        temp /= base;
    }
    result = malloc(length + 1);
    result[length] = '\0';
    for (int i = length - 1; i >= 0; i--) {
        result[i] = '0' + (nb % base);
        nb /= base;
    }
    return result;
}

int recuperate(pal_t *pal, int i)
{
    if (is_integer(pal->av[i + 1]) == 0)
        return atoi(pal->av[i + 1]);
    else{
        return -84;
    }
}
