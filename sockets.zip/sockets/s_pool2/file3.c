/*
** EPITECH PROJECT, 2024
** epitiech
** File description:
** epitech
*/

#include "struct.h"

int flag_n_and_p(pal_t *pal)
{
    if (strcmp(pal->av[1], "-n") == 0) {
        pal->nb_n++;
        pal->number = recuperate(pal, 1);
    } else if (strcmp(pal->av[1], "-p") == 0) {
        pal->nb_p++;
        pal->pal = recuperate(pal, 1);
    } else{
        free(pal);
        return 84;
    }
}

int recuperate_flag(pal_t *pal)
{
    for (pal->i = 3; pal->av[pal->i]; pal->i++) {
        if (strcmp(pal->av[pal->i], "-b") == 0) {
            pal->nb_b++;
            pal->base = recuperate(pal, pal->i);
            pal->i++;
            continue;
        }
        if (strcmp(pal->av[pal->i], "-imin") == 0) {
            pal->nb_imin++;
            pal->imin = recuperate(pal, pal->i);
            pal->i++;
            continue;
        }
        if (strcmp(pal->av[pal->i], "-imax") == 0) {
            pal->nb_imax++;
            pal->imax = recuperate(pal, pal->i);
            pal->i++;
            continue;
        }
    }
}

int error(pal_t *pal)
{
    if (pal->imax > 100 || pal->imin > 100) {
        printf("Invalid argument\n");
        return 1;
    }
    if (!(pal->base > 0 && pal->base <= 10)) {
        printf("Invalid argument\n");
        return 1;
    }
    if (pal->nb_b > 1 || pal->nb_imax > 1 || pal->nb_imin > 1) {
        printf("Invalid argument\n");
        return 1;
    }
    if (pal->imin > pal->imax) {
        printf("Invalid argument\n");
        return 1;
    }
    return 0;
}

int handling(pal_t *pal)
{
    if (pal->nb_n == 1) {
        pal->conv = convert_dec_to_base(pal->number, pal->base);
        pal->p = atoi(pal->conv);
        pal->t = iterations_to_palindrome(pal->p);
        pal->n = number_to_palindrome(pal->p);
        if (pal->base == 10) {
            printf("%d leads to %d in %d iteration(s) \
in base %d\n", pal->number, pal->n, pal->t, pal->base);
            return 0;
        }
        pal->convert = convert_base_to_dec(pal->n, pal->base);
        printf("%d leads to %d in %d iteration(s) \
in base %d\n", pal->number, pal->convert, pal->t, pal->base);
        return 0;
    }
}

int handling_flag_n(pal_t *pal)
{
    int i = 0;
    
    if (error(pal) == 1) { 
        free(pal);
        return 1;
    }
    if (pal->nb_n == 0) {
        return 0;
    }
    i = handling(pal);
    if (i == 0)
        return 0;
    return 1;
}
