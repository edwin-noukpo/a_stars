/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** son
*/

#include "struct.h"

int reverse_number(int n)
{
    int rev = 0;

    while (n > 0) {
        rev = rev * 10 + (n % 10);
        n /= 10;
    }
    return rev;
}

int is_palindrome(int n)
{
    if (n == reverse_number(n))
        return 1;
    return 0;
}

int iterations_to_palindrome(int n)
{
    int rev = 0;
    int iters = 0;

    while (!is_palindrome(n)) {
        rev = reverse_number(n);
        n = n + rev;
        iters++;
    }
    return iters;
}

int number_to_palindrome(int n)
{
    int rev = 0;
    int iters = 0;

    while (!is_palindrome(n)) {
        rev = reverse_number(n);
        n = n + rev;
        iters++;
    }
    return n;
}

int error_case(char **av)
{
    if (!(strcmp(av[1], "-n") == 0 || strcmp(av[1], "-p") == 0)) {
        printf("Invalid argument\n");
        return 84;
    }
    for (int i = 2; av[i]; i++) {
        if ((strcmp(av[i], "-imin") != 0 && strcmp(av[i], "-imax") != 0) &&
    strcmp(av[i], "-b") != 0 && is_integer(av[i]) == 1) {
        printf("Invalid argument\n");
            return 84;
        }
        if (i % 2 != 0 && is_integer(av[i]) == 0) {
            printf("Invalid command\n");
            return 84;
        }
        if (i % 2 == 0 && is_integer(av[i]) == 1) {
            printf("Invalid argument\n");
            return 84;
        }
    }
}
