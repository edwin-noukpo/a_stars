/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** ok
*/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

typedef struct my_struct {
    int ac;
    char **av;
    int i;
    int nb_n;
    int number;
    int nb_p;
    int pal;
    int nb_b;
    int base;
    int nb_imin;
    int imin;
    int nb_imax;
    int imax;
    int p;
    int t;
    int n;
    char *conv;
    int convert;
    int z;
    int numb;
    int n_conv;
    int check;
}pal_t;
int reverse_number(int n);
int error_case(char **av);
int recuperate(pal_t *pal, int i);
int flag_n_and_p(pal_t *pal);
int recuperate_flag(pal_t *pal);
int handling_flag_n(pal_t *pal);
int is_integer(char *str);
int error(pal_t *pal);
int iterations_to_palindrome(int n);
char *convert_dec_to_base(int nb, int base);
int convert_base_to_dec(int binary, int base);
int number_to_palindrome(int n);
int iterations_to_palindrome(int n);
int handling_flag_n(pal_t *pal);
