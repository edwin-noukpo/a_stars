/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** epi
*/

#include "struct.h"

void print_condition(pal_t *pal, int *pd, int y, int i)
{
    if (i >= pal->imin && pal->numb == y && i <= pal->imax) {
        if (pal->base == 10) {
            printf("%d leads to %d in %d iteration(s) \
in base %d\n", pal->n_conv, pal->pal, i, pal->base);
            (*pd)++;
        } else {
            pal->convert = convert_base_to_dec(y, pal->base);
            printf("%d\n", y);
            printf("%d leads to %d in %d iteration(s) \
in base %d\n", pal->convert, pal->pal, i, pal->base);
            (*pd)++;
        }
    }
}

void iteration(pal_t *pal, int y, int *i)
{
    int rev = 0;

    while (pal->numb < y && *i <= 101) {
        rev = reverse_number(pal->numb);
        pal->numb += rev;
        (*i)++;
    }
}

int condition(int pd)
{
    if (pd == 0) {
        printf("no solution\n");
        return 0;
    }
    return pd;
}

void palindrom_iteration(pal_t *pal)
{
    int y = 0;
    int pd = 0;
    int i = 0;

    if (pal->nb_p == 1) {
        pal->conv = convert_dec_to_base(pal->pal, pal->base);
        y = atoi(pal->conv);
        pd = 0;
        while (pal->z <= pal->pal) {
            pal->n_conv = pal->z;
            pal->numb = atoi(convert_dec_to_base(pal->z, pal->base));
            // printf("%d && %d\n", pal->z, pal->numb);
            i = 0;
            iteration(pal, y, &i);
            print_condition(pal, &pd, y, i);
            pal->z++;
        }
        pd = condition(pd);
    }
}

int main(int ac, char **av)
{
    if (ac == 1 || ac == 2 || ac % 2 == 0) {
        printf("Invalid command\n");
        return 84;
    }
    pal_t *pal = malloc(sizeof(pal_t));
    *pal = (pal_t) {ac, av, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 100, 0, 0, 0, NULL, 0, 0, 0, 0, 0};
    if (error_case(pal->av) == 84){
        free(pal);
        return 84;
    }
    if (flag_n_and_p(pal) == 84){
        free(pal);
        return 84;
    }
    recuperate_flag(pal);
    if (handling_flag_n(pal) == 1) {
        return 84;
    }
   palindrom_iteration(pal);
   free(pal->conv);
   free(pal);
}
