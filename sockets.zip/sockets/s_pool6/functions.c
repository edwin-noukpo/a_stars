/*
** EPITECH PROJECT, 2024
** calendar
** File description:
** moi
*/

#include "calendar.h"

int err_putchar(char c)
{
    write(2, &c, 1);
    return 1;
}

int err_putstr(char const *str)
{
    int i = 0;

    if (!str) {
        err_putstr("\033[32;01merr_putstr:\033[00m \
        The string is \033[34;01mNULL\033[00m\n");
        return 0;
    }
    while (str[i]) {
        err_putchar(str[i]);
        i++;
    }
    return i;
}

void *free_f(void *ptr)
{
    if (!ptr) {
        err_putstr("\033[32;01mfree_f:\033[00m \
        The string is \033[34;01mNULL\033[00m\n");
        return 0;
    }
    free(ptr);
    return 0;
}

void free_2d_array(char **map)
{
    if (!map) {
        err_putstr("\033[32;01mfree_2d_array:\033[00m \
        The 2d_array is \033[34;01mNULL\033[00m\n");
        return;
    }
    for (int i = 0; map[i]; i++)
        free_f(map[i]);
    free_f(map);
    return;
}

int charer(char *str, char c)
{
    int i = 0;

    for (; str[i]; i++)
        if (str[i] == c)
            return 1;
    return 0;
}

int line_count(char *str, char *seg)
{
    int i = 0;
    int j = 0;

    while (str[i]) {
        for (; str[i] && charer(seg, str[i]); i++);
        if (str[i] && !charer(seg, str[i]))
            j++;
        for (; str[i] && !charer(seg, str[i]); i++);
    }
    return j;
}

char **split_s(char *str, char *seg)
{
    int ln = line_count(str, seg);
    char **tab = malloc(sizeof(char *) * (ln + 1));
    split_t cut = (split_t){0, 0, 0, 0, 0};

    for (; cut.i < ln; cut.i++) {
        for (; charer(seg, str[cut.k]) && str[cut.k]; cut.k++);
        cut.a = 0;
        cut.b = cut.k;
        for (; !charer(seg, str[cut.k]) && str[cut.k]; cut.k++)
            cut.a++;
        tab[cut.i] = malloc(sizeof(char) * (cut.a + 1));
        for (cut.j = 0; cut.j < cut.a; cut.j++) {
            tab[cut.i][cut.j] = str[cut.b];
            cut.b++;
        }
        tab[cut.i][cut.j] = 0;
    }
    tab[cut.i] = 0;
    return tab;
}

char **split(char *str, char *seg)
{
    if (!str) {
        err_putstr("\033[32;01msplit:\033[00m \
        The str is \033[34;01mNULL\033[00m\n");
        return (char **)0x0;
    }
    if (!seg) {
        err_putstr("\033[32;01msplit:\033[00m \
        The seg is \033[34;01mNULL\033[00m\n");
        return (char **)0x0;
    }
    return split_s(str, seg);
}

char *read_line(void)
{
    char *buffer = 0;
    size_t size = 0;

    if (getline(&buffer, &size, stdin) == -1) {
        free(buffer);
        return 0;
    }
    return buffer;
}

int tab_len(char **tab)
{
    int i = 0;

    if (!tab) {
        err_putstr("\033[32;01mtab_len:\033[00m \
        The 2d_array is \033[34;01mNULL\033[00m\n");
        return -1;
    }
    for (i = 0; tab[i]; i++);
    return i;
}

int is_digit(char c)
{
    if (!(c >= '0' && c <= '9'))
        return 0;
    return 1;
}


int is_sign(char const c)
{
    if (c == '-' || c == '+')
        return 1;
    return 0;
}

int is_integer(char const *str)
{
    int i = 0;

    if (!str) {
        err_putstr("\033[32;01mis_integer:\033[00m \
        The string is \033[34;01mNULL\033[00m\n");
        return -1;
    }
    while (is_sign(str[i]))
        i++;
    while (str[i]) {
        if (!is_digit(str[i]))
            return 1;
        i++;
    }
    if (i == 0)
        return 1;
    return 0;
}
