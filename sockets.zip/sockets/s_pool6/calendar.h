/*
** EPITECH PROJECT, 2024
** calendar
** File description:
** epitech
*/
#include <stddef.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

typedef struct split {
    int a;
    int b;
    int i;
    int j;
    int k;
} split_t;

typedef	struct employee {
    char *name;
    char *forename;
    char *job;
    char *zipcode;
    int	id;
    struct employee *n;
} employee_t;

typedef struct meeting {
    char *place;
    char *date;
    int id;
    int *id_employee;
    int nb_employee;
    struct meeting *n;
} meeting_t;

void print_meeting(meeting_t *list);
void cancel_meeting(meeting_t **list, int id);
void print_employee(employee_t *list);
void new_employee(employee_t **list, employee_t *new);
void new_meeting(meeting_t **list, meeting_t *new);
void *free_f(void *ptr);
void free_2d_array(char **map);
char **split(char *str, char *seg);
char *read_line(void);
int err_putstr(char const *str);
int tab_len(char **tab);
int is_integer(char const *str);
void fire_employee(employee_t **list, int id);
void exclude_meeting(meeting_t **list, int id);
void free_employee(employee_t *list);
void free_meeting(meeting_t *list);
int is_employee(employee_t *list, int id);
int is_meeting(meeting_t *list, int id);
void info_employee(employee_t *list_employee, meeting_t *list_meeting);
char *format_date(char *date);
void remove_employee_to_meeting(meeting_t **list_meeting, employee_t *list_employee);