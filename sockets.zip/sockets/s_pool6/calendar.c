/*
** EPITECH PROJECT, 2024
** calendar
** File description:
** moi
*/

#include "calendar.h"

int main(int ac, char **av)
{
    if(!(ac == 1))
        return 84;
    employee_t *list_employee = (employee_t *)0x0;
    meeting_t *list_meeting = (meeting_t *)0x0;
    for (char *line = read_line(); line; line = read_line()) {
        char **tab_line = split(line, " \t\n");
        if (*tab_line && !strcmp("new_employee", *tab_line) && tab_len(tab_line) == 6) {
            employee_t *new = malloc(sizeof(employee_t));
            *new = (employee_t) {tab_line[1], tab_line[2], tab_line[3], tab_line[4], atoi(tab_line[5]), (employee_t *)0x0};
            new_employee(&list_employee, new);
        }
        if (*tab_line && !strcmp("new_meeting", *tab_line) && tab_len(tab_line) >= 6) {
            int x = 0;
            int *id_employee = malloc(sizeof(int) * 10);
            for (int index = 4; tab_line[index]; index++) {
                if (!is_integer(tab_line[index]) && !is_employee(list_employee, atoi(tab_line[index]))) {
                    id_employee[x] = atoi(tab_line[index]);
                    x++;
                }
            }
            meeting_t *new = malloc(sizeof(meeting_t));
            *new = (meeting_t) {tab_line[1], tab_line[2], atoi(tab_line[3]), id_employee, x, (meeting_t *)0x0};
            new_meeting(&list_meeting, new);
        }
        if (*tab_line && !strcmp("exclude", *tab_line)) {
            // free_2d_array(tab_line);
            // printf("%s\n", line);
        }
        if (*tab_line && !strcmp("invite", *tab_line)) {
            // free_2d_array(tab_line);
            // printf("%s\n", line);
        }
        if (*tab_line && !strcmp("cancel", *tab_line) && tab_len(tab_line) >= 2) {
            for (int index = 1; tab_line[index]; index++)
                if (!is_integer(tab_line[index]))
                    cancel_meeting(&list_meeting, atoi(tab_line[index]));
        }
        if (*tab_line && !strcmp("fire", *tab_line) && tab_len(tab_line) >= 2) {
            for (int index = 1; tab_line[index]; index++)
                if (!is_integer(tab_line[index]))
                    fire_employee(&list_employee, atoi(tab_line[index]));
            remove_employee_to_meeting(&list_meeting, list_employee);
        }
        if (*tab_line && !strcmp("info_meetings", *tab_line)) {
            // free_2d_array(tab_line);
            // printf("%s\n", line);
        }
        if (*tab_line && !strcmp("info_employees", *tab_line)) {
            info_employee(list_employee, list_meeting);
            // free_2d_array(tab_line);
            // printf("%s\n", line);
        }
        if (*tab_line && !strcmp("END", *tab_line) && tab_len(tab_line) == 1) {
            // print_employee(list_employee);
            // print_meeting(list_meeting);
            free_employee(list_employee);
            free_meeting(list_meeting);
            free_2d_array(tab_line);
            free_f(line);
            exit(0);
        }
        free_f(line);
    }
    return 0;
}
