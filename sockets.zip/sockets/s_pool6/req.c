/*
** EPITECH PROJECT, 2024
** list
** File description:
** list
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct my_list {
    void *data;
    struct my_list *next;
}list_t;

list_t *create_node(list_t *list, void *data)
{
    list_t *node = malloc(sizeof(list_t));
    node->data = data;
    node->next = NULL;
    return node;
}

void reverse_list(list_t **list)
{
    list_t *current = NULL;
    list_t *next = NULL;
    list_t *prev = NULL;

    if (*list == NULL)
        return;
    current = *list;
    while (current != NULL) {
        next = current->next;
	printf("current-next11 : %s\n", (char *)current->next);
        current->next = prev;
	printf("current-next222 : %s\n", (char *)current->next);
        prev = current;
	printf("prev = %s\n", (char *)prev);
        current = next;
	printf("current: %s\n", (char *)current);
    }
    *list = prev;
    printf("prev final : %s\n", (char *)prev);
}

void print_list(list_t *list)
{
    list_t *new = NULL;
    
    if (list == NULL)
        return;
    new = list;
    while (new != NULL) {
        printf("%s-->", (char *)new->data);
        new = new->next;
    }
    printf("NULL");
}

/*list_t *my_find(list_t *begin, void *data_ref, int (*cmp)(void *, void *))
{
    if (!begin)
	return;
    while (begin != NULL) {
	if (cmp(begin->data, data_ref) == 0)
	    return begin;
    }
    return NULL;
}

int main(int ac, char **av)
{
    list_t *head = create_node(head, "A");
    head->next = create_node(head, "B");
     head->next->next = create_node(head, "C");
    head->next->next->next = create_node(head, "D");
    printf("Linked list\n");
    print_list(head);
    printf("\n");
    printf("Reversed list\n");
    reverse_list(&head);
    print_list(head);
    printf("\n");
}
*/
