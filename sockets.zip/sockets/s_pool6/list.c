/*
** EPITECH PROJECT, 2024
** liste
** File description:
** epitech
*/

#include "calendar.h"

void print_meeting(meeting_t *list)
{
    for (meeting_t *tmp = list; tmp; tmp = tmp->n) {
	    printf("%s %s %d", tmp->place, tmp->date, tmp->id);
        for (int x = 0; x < tmp->nb_employee; x++) {
            if (x < tmp->nb_employee)
                printf(" ");
            printf("%d", tmp->id_employee[x]);
        }
        printf("\n");
    }
    return;
}

void print_employee(employee_t *list)
{
    for (employee_t *tmp = list; tmp; tmp = tmp->n)
	    printf("%s %s %s %s %d\n", tmp->name, tmp->forename, tmp->job, tmp->zipcode, tmp->id);
    return;
}

void new_employee(employee_t **list, employee_t *new)
{
    employee_t *tmp2 = (employee_t *)0x0;

    if (!is_employee(*list, new->id)) {
        free_employee(new);
        return;
    }
    if (!*list || strcmp((*list)->name, new->name) > 0) {
        new->n = *list;
        *list = new;
	    return;
    }
    for(tmp2 = *list; tmp2->n && strcmp(tmp2->n->name, new->name) < 0; tmp2 = tmp2->n);
    new->n = tmp2->n;
    tmp2->n = new;
	return;
}

char *format_date(char *date)
{
    int len_date = strlen(date) + 1;
    date = strdup(date);
    char **tab_date = split(date, "/");
    free_f(date);
    char *f_date = malloc(sizeof(char) * len_date);
    *f_date = 0;
    strcat(f_date, tab_date[2]);
    strcat(f_date, "/");
    strcat(f_date, tab_date[1]);
    strcat(f_date, "/");
    strcat(f_date, tab_date[0]);
    free_2d_array(tab_date);
    return f_date;
}

void new_meeting(meeting_t **list, meeting_t *new)
{
    meeting_t *tmp2 = (meeting_t *)0x0;

    char *f_date = format_date(new->date);
    if (!*list || strcmp(format_date((*list)->date), f_date) > 0) {
        new->n = *list;
        *list = new;
        free_f(f_date);
	    return;
    }
    for(tmp2 = *list; tmp2->n && strcmp(format_date(tmp2->n->date), f_date) < 0; tmp2 = tmp2->n);
    new->n = tmp2->n;
    tmp2->n = new;
    free_f(f_date);
	return;
}

int *change_tab_int(int *tab_int, int len_tab_int, int id)
{
    int *copy_tab_int = malloc(sizeof *copy_tab_int * (len_tab_int - 1));
    int y = 0;

    for (int x = 0; x < len_tab_int; x++) {
        if (tab_int[x] != id) {
            copy_tab_int[y] = tab_int[x];
            y++;
        }
    }
    return copy_tab_int;
}

void remove_employee_to_meeting(meeting_t **list_meeting, employee_t *list_employee)
{
    for (meeting_t *tmp_list_meeting = *list_meeting; tmp_list_meeting; tmp_list_meeting = tmp_list_meeting->n) {
        for (int x = 0; x < tmp_list_meeting->nb_employee; x++) {
            if (is_employee(list_employee, tmp_list_meeting->id_employee[x])) {
                tmp_list_meeting->id_employee = change_tab_int(tmp_list_meeting->id_employee, tmp_list_meeting->nb_employee, tmp_list_meeting->id_employee[x]);
                tmp_list_meeting->nb_employee -= 1;
                if (tmp_list_meeting->nb_employee == 1)
                    cancel_meeting(&(*list_meeting), tmp_list_meeting->id);
                    // cancel_meeting(list_meeting, tmp_list_meeting->id);
            }
        }
    }
    return;
}

int is_employee(employee_t *list, int id)
{
    for(employee_t *tmp = list; tmp; tmp = tmp->n)
        if (tmp->id == id)
            return 0;
    return 1;
}

int is_meeting(meeting_t *list, int id)
{
    for(meeting_t *tmp = list; tmp; tmp = tmp->n)
        if (tmp->id == id)
            return 0;
    return 1;
}

void fire_employee(employee_t **list, int id)
{
    employee_t *list_employee = *list;
    employee_t *p = (employee_t *)0x0;

    if ((*list)->id == id) {
        p = *list;
        *list = (*list)->n;
        free_f(p);
        return;
    }
    for (; list_employee->n && list_employee->n->id != id; list_employee = list_employee->n);
        if (list_employee->n) {
            p = list_employee->n;
            list_employee->n = list_employee->n->n;
            list_employee = list_employee->n;
            free_f(p);
            return;
        }
    return;
}

void cancel_meeting(meeting_t **list, int id)
{
    meeting_t *list_meeting = *list;
    meeting_t *p = (meeting_t *)0x0;

    if ((*list)->id == id) {
        p = *list;
        *list = (*list)->n;
        free_f(p);
        return;
    }
    for (; list_meeting->n && list_meeting->n->id != id; list_meeting = list_meeting->n);
        if (list_meeting->n) {
            p = list_meeting->n;
            list_meeting->n = list_meeting->n->n;
            list_meeting = list_meeting->n;
            free_f(p);
            return;
        }
    return;
}

void free_employee(employee_t *list)
{
    while (list) {
        employee_t *tmp = list;
        list = list->n;
        free_f(tmp->name);
        free_f(tmp->forename);
        free_f(tmp->job);
        free_f(tmp->zipcode);
        free_f(tmp);
    }
    return;
}

void free_meeting(meeting_t *list)
{
    while (list) {
        meeting_t *tmp = list;
        list = list->n;
        free_f(tmp->place);
        free_f(tmp->date);
        free_f(tmp->id_employee);
        free_f(tmp);
    }
    return;
}