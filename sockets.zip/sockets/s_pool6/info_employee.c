/*
** EPITECH PROJECT, 2024
** liste
** File description:
** epitech
*/

#include "calendar.h"

int with_employee(int *tab, int len_tab, int id)
{
    for (int count = 0; count < len_tab; count++)
        if (tab[count] == id)
            return 0;
    return 1;
}

void print_with_employee(employee_t *list, meeting_t *list_meeting, int act_id)
{
    for (employee_t *tmp = list; tmp; tmp = tmp->n) {
        if (tmp->id != act_id && !with_employee(list_meeting->id_employee, list_meeting->nb_employee, tmp->id))
	        printf(", %s %s", tmp->forename, tmp->name);
    }
    return;
}

void info_employee(employee_t *list_employee, meeting_t *list_meeting)
{
    for (employee_t *tmp_employee = list_employee; tmp_employee; tmp_employee = tmp_employee->n) {
        printf("******************************\n");
        printf("%s %s\nposition: %s\ncity: %s\n", tmp_employee->forename, tmp_employee->name, tmp_employee->job, tmp_employee->zipcode);
        for (meeting_t *tmp_meeting = list_meeting; tmp_meeting; tmp_meeting = tmp_meeting->n) {
            for (int count = 0; count < tmp_meeting->nb_employee; count++) {
                if (tmp_meeting->id_employee[count] == tmp_employee->id) {
                    printf("meeting on %s, %s, with", tmp_meeting->date, tmp_meeting->place);
                    print_with_employee(list_employee, tmp_meeting, tmp_employee->id);
	                printf("\n");
                }
            }
        }
    }
    return;
}