#ifndef BREAKOUT_CLOCK_H
#define BREAKOUT_CLOCK_H

typedef struct
{
    int s;
    int ms;
} CLOCK;

#endif
