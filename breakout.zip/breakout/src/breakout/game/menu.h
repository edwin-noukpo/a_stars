#ifndef BREAKOUT_GAME_MENU_H
#define BREAKOUT_GAME_MENU_H

#include <breakout/game.h>

void game_menu_frame(GAME *game, const char *title);

#endif
