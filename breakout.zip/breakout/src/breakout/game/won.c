#include "over.h"
#include "menu.h"

void game_won_frame(GAME *game)
{
    game_menu_frame(game, "YOU WON");
}
