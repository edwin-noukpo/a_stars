#ifndef BREAKOUT_GAME_WON_H
#define BREAKOUT_GAME_WON_H

#include <breakout/game.h>

void game_won_frame(GAME *game);

#endif
