#ifndef BREAKOUT_GAME_OVER_H
#define BREAKOUT_GAME_OVER_H

#include <breakout/game.h>

void game_over_frame(GAME *game);

#endif
