#ifndef BREAKOUT_GAME_PLAY_H
#define BREAKOUT_GAME_PLAY_H

#include <breakout/game.h>

void game_play_frame(GAME *game);

#endif
