#include "over.h"
#include "menu.h"

void game_over_frame(GAME *game)
{
    game_menu_frame(game, "GAME OVER");
}
