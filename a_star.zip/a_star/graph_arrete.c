#include <stdio.h>
#include <stdlib.h>
 
// Définit le nombre maximum de sommets dans le graphe
#define N 6
 
// Structure de données pour stocker un objet graph
struct Graph
{
    // Un array de pointeurs vers Node pour représenter une liste de contiguïté
    struct Node* head[N];
};
 
// Structure de données pour stocker les nœuds de la liste d'adjacence du graphe
struct Node
{
    int dest, weight;
    struct Node* next;
};
 
// Structure de données pour stocker une arête de graphe
struct Edge {
    int src, dest, weight;
};
 
// Fonction pour créer une liste d'adjacence à partir des arêtes spécifiées
struct Graph* createGraph(struct Edge edges[], int n)
{
    // alloue de l'espace de stockage pour la structure de données du graphe
    struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph));
 
    // initialise le pointeur principal pour tous les sommets
    for (int i = 0; i < N; i++) {
        graph->head[i] = NULL;
    }
 
    // ajoute les arêtes au graphe orienté une par une
    for (int i = 0; i < n; i++)
    {
        // récupère le sommet source et destination
        int src = edges[i].src;
        int dest = edges[i].dest;
        int weight = edges[i].weight;
 
        // alloue un nouveau noeud de la liste d'adjacence de src à dest
        struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
        newNode->dest = dest;
        newNode->weight = weight;
 
        // pointe le nouveau nœud vers la tête actuelle
        newNode->next = graph->head[src];
 
        // pointe le pointeur principal vers le nouveau nœud
        graph->head[src] = newNode;
    }
 
    return graph;
}
 
// Fonction pour imprimer la représentation de la liste d'adjacence d'un graphe
void printGraph(struct Graph* graph)
{
    for (int i = 0; i < N; i++)
    {
        // affiche le sommet courant et tous ses voisins
        struct Node* ptr = graph->head[i];
        while (ptr != NULL)
        {
            printf("%d —> %d (%d)\t", i, ptr->dest, ptr->weight);
            ptr = ptr->next;
        }
 
        printf("\n");
    }
}
 
// Implémentation d'un graphe orienté pondéré en C
int main(void)
{
    // array d'entrée contenant les bords du graph (selon le schéma ci-dessus)
    // (x, y, w) le tuple représente une arête de x à y ayant le poids `w`
    struct Edge edges[] =
    {
        {0, 1, 6}, {1, 2, 7}, {2, 0, 5}, {2, 1, 4}, {3, 2, 10}, {4, 5, 1}, {5, 4, 3}
    };
 
    // calcule le nombre total d'arêtes
    int n = sizeof(edges)/sizeof(edges[0]);
 
    // construit un graphe à partir des arêtes données
    struct Graph *graph = createGraph(edges, n);
 
    // Fonction pour imprimer la représentation de la liste d'adjacence d'un graphe
    printGraph(graph);
 
    return 0;
}
