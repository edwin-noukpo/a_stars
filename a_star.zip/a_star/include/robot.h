/*
** EPITECH PROJECT, 2024
** ASM
** File description:
** ASM
*/

#ifndef _ASM_
    #define _ASM_
    #include <limits.h>
void set_node_open(open_t **list_open, int *data);
void disp_open(open_t *list);
void free_open(open_t *list);
void delete_node(open_t **list);
void set_node_neighbor(neighbor_t **list_neighbor, int *data);
void free_neighbor(neighbor_t *list);
void disp_neighbor(neighbor_t *list);
int is_node_open(open_t *list_open, int x_pos, int y_pos);
void set_node_camefrom(camefrom_t **list_camefrom, int x_s, int y_s, int x_p, int y_p);
void disp_camefrom(camefrom_t *list);
void free_camefrom(camefrom_t *list);
void set_node_closed(closed_t **list_closed, int *data);
void free_closed(closed_t *list);
int is_node_closed(closed_t *list_closed, int x_pos, int y_pos);
#endif /* !_ASM_ */
