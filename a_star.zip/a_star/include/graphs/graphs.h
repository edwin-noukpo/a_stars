/*
** EPITECH PROJECT, 2024
** MINISHELL 1
** File description:
** Function to count number of line of an array
*/

#ifndef _GRAPHS_
    #define _GRAPHS_

#endif /* !_GRAPHS_ */
