/*
** EPITECH PROJECT, 2024
** add
** File description:
** add
*/
#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

typedef struct ram{
    int id;
    char *name;
    char *type;
    struct ram *next;
}ram_t;


// ram_t *add_at_beginning(ram_t *head, int id, char *name, char *type)
// {
//     ram_t *new_node = (ram_t *)malloc(sizeof(ram_t));

//     new_node->id = id;
//     new_node->name = strdup(name);
//     new_node->type = strdup(type);
//     new_node->next = head;
//     head = new_node;
//     return head;
// }
// ram_t *add_at_beginning(ram_t *head, int id, char *name, char *type)
// {
//     ram_t *new_node = (ram_t *)malloc(sizeof(ram_t));

//     new_node->id = id;
//     new_node->name = strdup(name);
//     new_node->type = strdup(type);
//     new_node->next = NULL;

//     if (!head) {
//         head = new_node;
//         return head;
//     }
//     new_node->next = head;
//     head = new_node;
//     return head;
// }
// ram_t *add_at_beginning(ram_t *head, int id, char *name, char *type)
// {
//     ram_t *new_node = (ram_t *)malloc(sizeof(ram_t));

//     new_node->id = id;
//     new_node->name = strdup(name);
//     new_node->type = strdup(type);
//     new_node->next = NULL;

//     if (head == NULL) {
//         head = new_node;
//         return head;
//     }
//     new_node->next = head;
//     head = new_node;
//     return head;
// }
ram_t *add_at_beginning(ram_t *head, int id, char *name, char *type)
{
    ram_t *new_node = (ram_t *)malloc(sizeof(ram_t));

    *new_node = (ram_t) {id, strdup(name), strdup(type), (ram_t *)0x0};

    if (!head) {
        head = new_node;
        return head;
    }
    new_node->next = head;
    head = new_node;
    return head;
}
void print_mylist(ram_t *head)
{
    ram_t *current = head;
    while (current != NULL) {
        printf("%s n°%d - \"%s\"\n", current->type,
            current->id, current->name);
        current = current->next;
    }
}

int main(int ac, char **av)
{
    ram_t *head = NULL;
    head = add_at_beginning(head, 5, "Nabil", "masculin");
    head = add_at_beginning(head, 8, "sister", "feminin");
    head = add_at_beginning(head, 6, "Nabilath", "feminin");
    head = add_at_beginning(head, 4, "Isaac", "masculin");
    print_mylist(head);
}