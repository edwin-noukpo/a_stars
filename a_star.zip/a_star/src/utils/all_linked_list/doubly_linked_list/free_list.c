/*
** EPITECH PROJECT, 2024
** palindrome
** File description:
** palindrome
*/

#include "../../../../include/all_linked_list/doubly_linked_list/d_list.h"
