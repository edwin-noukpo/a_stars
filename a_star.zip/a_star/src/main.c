/*
** EPITECH PROJECT, 2024
** MY_NAVY
** File description:
** Function to count number of word in a function
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "../include/utils.h"
#include "../include/struct.h"
#include "../include/robot.h"
#include "../include/all_linked_list/doubly_linked_list/d_list.h"
#include "../include/tree/tree.h"
#include <dirent.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <time.h>
#include <stdio.h>
#include <math.h>

#define RED     "\x1b[31m"
#define GREEN   "\x1b[32m"
#define YELLOW  "\x1b[33m"
#define BLUE    "\x1b[34m"
#define MAGENTA "\x1b[35m"
#define CYAN    "\x1b[36m"
#define RESET   "\x1b[0m"

int heuristics_dia(int x_a, int y_a, int x_b, int y_b)
{
    return sqrt(pow((x_b - x_a), 2) + pow((y_b - y_a), 2));
    // return abs(x_b - x_a) + abs(y_b - y_a);
}

void retrieve_neighbor(neighbor_t **list_neighbor, char **map, int *data_current, int x_g, int y_g, closed_t *list_closed)
{
    int *data = malloc(sizeof(int) * 6);

    if (map[data_current[3] + 1][data_current[4]] != '#' && !is_node_closed(list_closed, data_current[3] + 1, data_current[4])) {
        data[0] = data_current[0] + 10;
        data[1] = heuristics_dia(data_current[3] + 1, data_current[4], x_g, y_g);
        data[2] = data[0] + data[1];
        data[3] = data_current[3] + 1;
        data[4] = data_current[4];
        set_node_neighbor(list_neighbor, data);
    }
    if (map[data_current[3] - 1][data_current[4]] != '#' && !is_node_closed(list_closed, data_current[3] - 1, data_current[4])) {
        data[0] = data_current[0] + 10;
        data[1] = heuristics_dia(data_current[3] - 1, data_current[4], x_g, y_g);
        data[2] = data[0] + data[1];
        data[3] = data_current[3] - 1;
        data[4] = data_current[4];
        set_node_neighbor(list_neighbor, data);
    }
    if (map[data_current[3]][data_current[4] + 1] != '#' && !is_node_closed(list_closed, data_current[3], data_current[4] + 1)) {
        data[0] = data_current[0] + 10;
        data[1] = heuristics_dia(data_current[3], data_current[4] + 1, x_g, y_g);
        data[2] = data[0] + data[1];
        data[3] = data_current[3];
        data[4] = data_current[4] + 1;
        set_node_neighbor(list_neighbor, data);
    }
    if (map[data_current[3]][data_current[4] - 1] != '#' && !is_node_closed(list_closed, data_current[3], data_current[4] - 1)) {
        data[0] = data_current[0] + 10;
        data[1] = heuristics_dia(data_current[3], data_current[4] - 1, x_g, y_g);
        data[2] = data[0] + data[1];
        data[3] = data_current[3];
        data[4] = data_current[4] - 1;
        set_node_neighbor(list_neighbor, data);
    }
    if (map[data_current[3] - 1][data_current[4] - 1] != '#' && !is_node_closed(list_closed, data_current[3] - 1, data_current[4] - 1)) {
        data[0] = data_current[0] + 14;
        data[1] = heuristics_dia(data_current[3] - 1, data_current[4] - 1, x_g, y_g);
        data[2] = data[0] + data[1];
        data[3] = data_current[3] - 1;
        data[4] = data_current[4] - 1;
        set_node_neighbor(list_neighbor, data);
    }
    if (map[data_current[3] + 1][data_current[4] + 1] != '#' && !is_node_closed(list_closed, data_current[3] + 1, data_current[4] + 1)) {
        data[0] = data_current[0] + 14;
        data[1] = heuristics_dia(data_current[3] + 1, data_current[4] + 1, x_g, y_g);
        data[2] = data[0] + data[1];
        data[3] = data_current[3] + 1;
        data[4] = data_current[4] + 1;
        set_node_neighbor(list_neighbor, data);
    }
    if (map[data_current[3] - 1][data_current[4] + 1] != '#' && !is_node_closed(list_closed, data_current[3] - 1, data_current[4] + 1)) {
        data[0] = data_current[0] + 14;
        data[1] = heuristics_dia(data_current[3] - 1, data_current[4] + 1, x_g, y_g);
        data[2] = data[0] + data[1];
        data[3] = data_current[3] - 1;
        data[4] = data_current[4] + 1;
        set_node_neighbor(list_neighbor, data);
    }
    if (map[data_current[3] + 1][data_current[4] - 1] != '#' && !is_node_closed(list_closed, data_current[3] + 1, data_current[4] - 1)) {
        data[0] = data_current[0] + 14;
        data[1] = heuristics_dia(data_current[3] + 1, data_current[4] - 1, x_g, y_g);
        data[2] = data[0] + data[1];
        data[3] = data_current[3] + 1;
        data[4] = data_current[4] - 1;
        set_node_neighbor(list_neighbor, data);
    }
    free_f(data);
    return;
}

void a_star(int x_s, int y_s, int x_g, int y_g, int distance, char **map)
{
    open_t *list_open = (open_t *)0x0;
    closed_t *list_closed = (closed_t *)0x0;
    camefrom_t *list_camefrom = (camefrom_t *)0x0;
    int *data_pose = malloc(sizeof(int) * 7);

    data_pose[0] = 0;
    data_pose[1] = distance;
    data_pose[2] = distance;
    data_pose[3] = x_s;
    data_pose[4] = y_s;
    data_pose[5] = x_s;
    data_pose[6] = y_s;
    set_node_camefrom(&list_camefrom, data_pose[3], data_pose[4], data_pose[5], data_pose[6]);
    set_node_open(&list_open, data_pose);

    while(list_open) {
        if (list_open->x_pos == x_g && list_open->y_pos == y_g) {
            camefrom_t *verif_camefrom = list_camefrom;
            for(; verif_camefrom; verif_camefrom = verif_camefrom->n) {
                if (verif_camefrom->x_pos == x_g && verif_camefrom->y_pos == y_g) {
                    camefrom_t *tmp_camefrom = verif_camefrom;
                    map[verif_camefrom->x_pos][verif_camefrom->y_pos] = 'o';
                    for(; tmp_camefrom; tmp_camefrom = tmp_camefrom->p)
                        if (tmp_camefrom->p)
                            map[tmp_camefrom->p->x_pos][tmp_camefrom->p->y_pos] = 'o';
                }
            }
            free_open(list_open);
            free_camefrom(list_camefrom);
            free_closed(list_closed);
            map[x_s][y_s] = '*';
            map[x_g][y_g] = 'x';
            return;
        }
        int *data_current = malloc(sizeof(int) * 7);
        data_current[0] = list_open->g_cost;
        data_current[1] = list_open->h_cost;
        data_current[2] = list_open->f_cost;
        data_current[3] = list_open->x_pos;
        data_current[4] = list_open->y_pos;
        data_current[5] = list_open->x_prev;
        data_current[6] = list_open->y_prev;
        int *data_closed = malloc(sizeof(int) * 2);
        data_closed[0] = list_open->x_pos;
        data_closed[1] = list_open->y_pos;
        map[data_closed[0]][data_closed[1]] = '+';
        set_node_closed(&list_closed, data_closed);
        free_f(data_closed);
        delete_node(&list_open);

        neighbor_t *list_neighbor = (neighbor_t *)0x0;

        retrieve_neighbor(&list_neighbor, map, data_current, x_g, y_g, list_closed);

        neighbor_t *tmp_neighbor = list_neighbor;
        for(; tmp_neighbor; tmp_neighbor = tmp_neighbor->n) {
            int tentative_g_cost = data_current[0] + heuristics_dia(data_current[3], data_current[4], tmp_neighbor->x_pos, tmp_neighbor->y_pos);

            if (tentative_g_cost < tmp_neighbor->g_cost) {
                tmp_neighbor->g_cost = tentative_g_cost;
                tmp_neighbor->f_cost = tmp_neighbor->g_cost + tmp_neighbor->h_cost;
                if (!is_node_open(list_open, tmp_neighbor->x_pos, tmp_neighbor->y_pos)) {
                    int *data_pose = malloc(sizeof(int) * 7);
                    data_pose[0] = tmp_neighbor->g_cost;
                    data_pose[1] = tmp_neighbor->h_cost;
                    data_pose[2] = tmp_neighbor->f_cost;
                    data_pose[3] = tmp_neighbor->x_pos;
                    data_pose[4] = tmp_neighbor->y_pos;
                    data_pose[5] = data_current[3];
                    data_pose[6] = data_current[4];
                    map[data_pose[3]][data_pose[4]] = '.';
                    set_node_camefrom(&list_camefrom, data_pose[3], data_pose[4], data_pose[5], data_pose[6]);
                    set_node_open(&list_open, data_pose);
                }
            }
        }
        free_f(data_current);
        free_neighbor(list_neighbor);
    }
    free_open(list_open);
    free_camefrom(list_camefrom);
    free_closed(list_closed);
    map[x_s][y_s] = '*';
    return;
}

void disp_line(char *line)
{
    for(int x = 0; line[x]; x++) {
        if (line[x] == '.')
            mini_printf(BLUE "%c" RESET, line[x]);
        if (line[x] == 'o')
            mini_printf(RED "%c" RESET, line[x]);
        if (line[x] == '#')
            mini_printf(BLUE "%c" RESET, line[x]);
            // mini_printf(GREEN "%c" RESET, line[x]);
        if (line[x] == 'x')
            mini_printf(YELLOW "%c" RESET, line[x]);
        if (line[x] == '*')
            mini_printf(YELLOW "%c" RESET, line[x]);
        if (line[x] == '+')
            mini_printf(MAGENTA "%c" RESET, line[x]);
        if (line[x] == ' ')
            mini_printf("%c", line[x]);
        if (!line[x + 1])
            mini_printf("\n");
    }
}

void disp_map(char **map)
{
    for(int x = 0; map[x]; x++)
        disp_line(map[x]);
    return;
}

int main(int ac, char **av)
{
    if (ac != 2)
        return 84;
    int fd = fs_open_file(av[1]);
    char *content = read_map(fd, av[1]);
    char **map = split(content, "\n");
    int *data_pose = malloc(sizeof(int) * 4);
    for(int x = 0; map[x]; x++)
        for(int y = 0; map[x][y]; y++) {
            map[x][y] == '*' ? data_pose[0] = x : data_pose[0];
            map[x][y] == '*' ? data_pose[1] = y : data_pose[1];
            map[x][y] == 'x' ? data_pose[2] = x : data_pose[2];
            map[x][y] == 'x' ? data_pose[3] = y : data_pose[3];
        }
    int distance_target = heuristics_dia(data_pose[0], data_pose[1], data_pose[2], data_pose[3]);
    a_star(data_pose[0], data_pose[1], data_pose[2], data_pose[3], distance_target, map);
    disp_map(map);
    free_f(data_pose);
    free_f(content);
    free_2d_array(map);
    return 0;
}
