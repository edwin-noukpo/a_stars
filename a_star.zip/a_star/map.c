#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define WIDTH 200 // Maze width (must be odd)
#define HEIGHT 50 // Maze height (must be odd)

// Directions for maze carving (up, down, left, right)
int dx[] = {0, 0, 2, -2};
int dy[] = {2, -2, 0, 0};
// int dx[] = {0, 0, 1, -1};
// // int dy[] = {1, -1, 0, 0};
// int dx[] = {0, 0, 2, -4};
// int dy[] = {4, -1, 0, 0};
// int dx[] = {0, 1, 2, -4};
// int dy[] = {4, -1, 0, 0};
// int dx[] = {0, 1, -2, -4};
// int dy[] = {4, -1, 0, 0};
// int dx[] = {0, 1, -2, -4};
// int dy[] = {4, -1, 0, 0};

// Function prototypes
void initialize_maze(char maze[HEIGHT][WIDTH]);
void carve_maze(char maze[HEIGHT][WIDTH], int x, int y);
void print_maze(char maze[HEIGHT][WIDTH]);
void reduce_maze_density(char maze[HEIGHT][WIDTH], float reduction_rate) {
    for (int i = 1; i < HEIGHT - 1; i++) {
        for (int j = 1; j < WIDTH - 1; j++) {
            if (maze[i][j] == '#') {
                if ((rand() / (float)RAND_MAX) < reduction_rate) {
                    maze[i][j] = ' ';  // Remplace le mur par un chemin avec une probabilité
                }
            }
        }
    }
}

int main() {
    srand(time(NULL));  // Seed random number generator

    char maze[HEIGHT][WIDTH];
    initialize_maze(maze);

    // Start carving the maze from (1,1)
    carve_maze(maze, 1, 1);

    // Set start point and end point
    maze[1][1] = '*';  // Start
    maze[HEIGHT - 2][WIDTH - 2] = 'x';  // End

    // Print the maze
    print_maze(maze);

    return 0;
}

// Initialize the maze with walls (#) everywhere
void initialize_maze(char maze[HEIGHT][WIDTH]) {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            maze[i][j] = '#';  // Set all cells as walls initially
        }
    }
}

// Recursive backtracking algorithm to carve out the maze
void carve_maze(char maze[HEIGHT][WIDTH], int x, int y) {
    // Mark the current cell as part of the path
    maze[y][x] = ' ';

    // Randomly shuffle the directions
    int directions[4] = {0, 1, 2, 3};
    for (int i = 0; i < 4; i++) {
        int r = rand() % 4;
        int temp = directions[i];
        directions[i] = directions[r];
        directions[r] = temp;
    }

    // Try to carve a path in each direction
    for (int i = 0; i < 4; i++) {
        int nx = x + dx[directions[i]];  // Next x
        int ny = y + dy[directions[i]];  // Next y

        // Check if the next cell is within bounds and is still a wall
        if (nx > 0 && nx < WIDTH - 1 && ny > 0 && ny < HEIGHT - 1 && maze[ny][nx] == '#') {
            // Carve a passage between the current cell and the next cell
            maze[(y + ny) / 2][(x + nx) / 2] = ' ';

            // Recursively carve the next cell
            carve_maze(maze, nx, ny);
        }
        // reduce_maze_density(maze, 0.0005);
    }
}

// Print the maze to the console
void print_maze(char maze[HEIGHT][WIDTH]) {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            printf("%c", maze[i][j]);
        }
        printf("\n");
    }
}
